import { Component, OnInit, ViewChild, ChangeDetectorRef, ElementRef } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { ChequeAccountingService } from '../Services/cheque-accounting.service';
import { AppCode } from '../../../app.code';
// import * as XLSX from 'xlsx';

@Component({
  selector: 'app-cheque-register-summary-report',
  templateUrl: './cheque-register-summary-report.component.html',
  styleUrls: ['./cheque-register-summary-report.component.scss']
})
export class ChequeRegisterSummaryReportComponent implements OnInit {

  Chequesmmryreport = ['SrNo', 'StockistNo', 'StockistName', 'BankName', 'IFSCCode', 'AccountNo', 'BlankChqs', 'UtilisedChqs',
    'PrepareChqs', 'DiscardedChqs', 'DepositedChqs', 'ReturnedChqs'];

  @ViewChild('paginator') paginator: MatPaginator;
  @ViewChild('Sort') Sort: MatSort;
  @ViewChild('TABLE') table: ElementRef;
  public DataSource = new MatTableDataSource<any>()

  isLoading: boolean = false;
  UserId: number = 0;
  BranchId: number = 0;
  CompanyId: number = 0;
  searchModel: string = '';
  Title: string;
  fileName: string = "chequeRegisterSummaryCountReport";

  constructor(private chequeAccountingService: ChequeAccountingService, private chRef: ChangeDetectorRef) { }

  ngOnInit(): void {
    this.Title = "Cheque Register Summary Report";
    let obj = AppCode.getUser();
    this.UserId = obj.UserId;
    this.BranchId = obj.BranchId;
    this.CompanyId = obj.CompanyId;
    this.GetStockistOutstanding();
  }

  // get Cheque Register Summary Report List
  GetStockistOutstanding() {
    this.isLoading = true;
    this.chequeAccountingService.getChequeRegistersmryLst_Service(this.BranchId, this.CompanyId).subscribe((data: any) => {
      if (data.length > 0) {
        this.DataSource.data = data;
        this.DataSource.paginator = this.paginator;
        this.DataSource.sort = this.Sort;
        this.isLoading = false;
        this.chRef.detectChanges();
      } else {
        this.DataSource.data = [];
        this.isLoading = false;
        this.chRef.detectChanges();
      }
      (error: any) => {
        console.log(error);
      }
    });
  }

  // Search - Apply Filter
  applyFilter() {
    this.isLoading = true;
    // this.searchModel = this.searchModel.trim(); // Remove whitespace
    this.searchModel = this.searchModel.toLowerCase(); // Datasource defaults to lowercase matches
    this.DataSource.filter = this.searchModel;
    this.isLoading = false;
    this.chRef.detectChanges(); // IMMEDIATE ACTION FIRED
  }

  //export excel
  exportAsExcel() {
    // const ws: XLSX.WorkSheet = XLSX.utils.table_to_sheet(this.table.nativeElement);
    // const wb: XLSX.WorkBook = XLSX.utils.book_new();
    // XLSX.utils.book_append_sheet(wb, ws, 'All Data Export');
    // XLSX.writeFile(wb, 'chequeRegisterSummaryCountReport.xlsx');

    AppCode.exportToExcelFile(this.fileName, this.table);
  }

}
