import { Component, OnInit, ViewChild, ChangeDetectorRef } from '@angular/core';

import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';

import { Router } from '@angular/router';

import { ApproveVehicleModel, InvInwardAllCountModel } from '../models/ApproveVehicleModel';
import { InsuranceModel } from '../models/InsuranceModel';

import { SharedService } from '../../../SharedServices/shared.service';
import { InventoryInwardService } from '../Services/inventory-inward.service';
import { AppCode } from '../../../app.code';
import { ToastrService } from 'ngx-toastr';
import Swal from 'sweetalert2';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-approve-vehicle-issue',
  templateUrl: './approve-vehicle-issue.component.html',
  styleUrls: ['./approve-vehicle-issue.component.scss'],
  providers: [DatePipe]
})
export class ApproveVehicleIssueComponent implements OnInit {
  isLoading: boolean = false;
  ApproveVehicleforApi = ['SrNo', 'LRNo', 'TransporterNo', 'TransporterName', 'LRDate', 'VehicleNo', 'Actions'];
  @ViewChild('paginator') paginator: MatPaginator;
  @ViewChild('Sort') Sort: MatSort;
  public DataSource = new MatTableDataSource<any>();
  searchModel: string = "";
  UserId: number = 0;
  BranchId: number = 0;
  CompanyId: number = 0;
  approvevehiclemodel: ApproveVehicleModel;

  DataModel: any;

  invInwardAllCount: InvInwardAllCountModel;
  TodayLRCnt: number = 0;

  TodayMapConcernRaisedCnt: number = 0;
  TodayMapConcernResolvedCnt: number = 0;
  LRCountList: any;
  ResolveVehicleList: any;
  TotalTodaysMapCnrnRaiseCnt: number;
  currentDate = new Date();


  constructor(private chref: ChangeDetectorRef, private _service: InventoryInwardService,
    private router: Router, private toaster: ToastrService, private _SharedService: SharedService, private datepipe: DatePipe) { this.currentDate = new Date(); }

  ngOnInit(): void {
    let obj = AppCode.getUser();
    this.UserId = obj.UserId;
    this.BranchId = obj.BranchId;
    this.CompanyId = obj.CompanyId;
    this.GetMapInwardVehicleRaiseCncrnList();
    this.DataModel = {
      BranchId: this.BranchId,
      CompId: this.CompanyId
    }
    this.GetApproveVehicleIssueCounts(this.DataModel);
  }

  //Get Vehicle CheckList
  GetMapInwardVehicleRaiseCncrnList() {
    this.isLoading = true;
    this._service.GetMapInwardVehicleRaiseCncrnList_Service(this.BranchId, this.CompanyId).subscribe((data: any) => {
      if (data.length > 0) {
        this.DataSource.data = data;
        this.ResolveVehicleList = data;
        this.DataSource.paginator = this.paginator;
        this.DataSource.sort = this.Sort;
      } else {
        this.DataSource.data = [];
      }
      this.isLoading = false;
      this.chref.detectChanges();
      (error: any) => {
        console.log(error);
        this.isLoading = false;
        this.chref.detectChanges();
      }
    });
  }

  // Raise Claim
  GetDataClaim(row: InsuranceModel) {
    this._SharedService.setData(row);
    this.router.navigate(['/modules/inventory-inward/add-insurance-claim'], { queryParams: { state: AppCode.raiseClaimstring } });
  }

  //Approve Function
  ApproveVehicle(row: ApproveVehicleModel) {
    Swal.fire({
      title: 'Are you sure?',
      text: "Do you want to resolve?",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, resolve it!'
    }).then((result) => {
      if (result.isConfirmed) {
        this.approvevehiclemodel = new ApproveVehicleModel();
        this.approvevehiclemodel.PkId = row.PkId;
        this.approvevehiclemodel.BranchId = this.BranchId;
        this.approvevehiclemodel.CompId = this.CompanyId;
        this.approvevehiclemodel.IsConcern = 0;
        this.approvevehiclemodel.AddedBy = this.UserId;
        this._service.ResolveVehicleIssue_Url_Service(this.approvevehiclemodel)
          .subscribe((data: any) => {
            if (data > 0) {
              this.toaster.success(AppCode.msg_ResolveSuccess);
              this.GetMapInwardVehicleRaiseCncrnList();
              this.GetApproveVehicleIssueCounts(this.DataModel); //
            }
          }, (error: any) => {
            console.error(error);
            this.chref.detectChanges();
          });
      }
    });
  }

  // Raise SAN
  GetDataSAN(row: InsuranceModel) {
    this._SharedService.setData(row);
    this.router.navigate(['/modules/inventory-inward/add-insurance-claim'], { queryParams: { state: AppCode.raiseSANstring } });
  }

  // Search - Apply Filter
  applyFilter() {
    this.isLoading = true;
    this.searchModel = this.searchModel.toLowerCase(); // Datasource defaults to lowercase matches
    this.DataSource.filter = this.searchModel;
    this.isLoading = false;
    this.chref.detectChanges(); // IMMEDIATE ACTION FIRED
  }

  //Get Approve Vehicle Issue Counts Counts
  GetApproveVehicleIssueCounts(DataModel: any) {
    this.isLoading = true;
    this._service.GetInvInwardAllCounts(DataModel)
      .subscribe((data: any) => {
        if (data != null) {
          this.afterCount(data);
        }
      }, (error: any) => {
        console.error("Error:  " + JSON.stringify(error));
        this.isLoading = false;
        this.chref.detectChanges();
      });
  }

  afterCount(data: InvInwardAllCountModel) {
    this.invInwardAllCount = new InvInwardAllCountModel();
    this.invInwardAllCount = data;
    this.TodayLRCnt = this.invInwardAllCount.TodayLR;
    this.TotalTodaysMapCnrnRaiseCnt = this.invInwardAllCount.TotalTodaysMapCnrnRaise;
    this.TodayMapConcernRaisedCnt = this.invInwardAllCount.TodayMapConcernRaised;
    this.TodayMapConcernResolvedCnt = this.invInwardAllCount.TodayMapConcernResolved;
    this.isLoading = false;
    this.chref.detectChanges();
  }

  // LR Recived List after filtering count wise
  ShowLRList(Flag: string) {
    this.isLoading = true;
    if (this.ResolveVehicleList != null && this.ResolveVehicleList !== undefined) {
      if (Flag === 'ClaimRaised') {
        this.LRCountList = this.ResolveVehicleList.filter((x: any) => x.IsClaim === 1);
      } else if (Flag === 'TotalTodaysMapCnrnRaiseCnt') {
        this.LRCountList = this.ResolveVehicleList;
      } else if (Flag === 'MapConcernRaised') {
        //this.LRCountList = this.ResolveVehicleList.filter((x: any) => (x.LRDate === String(this.datepipe.transform(this.currentDate, AppCode.DateOnlyFormatT))));
        this.LRCountList = this.ResolveVehicleList.filter((x: any) => (x.IsConcern === 1));
      } else if (Flag === 'MapConcernResolved') {
        //this.LRCountList = this.ResolveVehicleList.filter((x: any) => x.LRDate === String(this.datepipe.transform(this.currentDate, AppCode.DateOnlyFormatT)) || x.ResolvedBy > 0);
        this.LRCountList = this.ResolveVehicleList.filter((x: any) => (x.ResolvedBy > 0));
      }
      this.DataSource = new MatTableDataSource(this.LRCountList);
      this.DataSource.paginator = this.paginator;
      this.DataSource.sort = this.Sort;
      this.isLoading = false;
      this.chref.detectChanges();
    }
  }

}
