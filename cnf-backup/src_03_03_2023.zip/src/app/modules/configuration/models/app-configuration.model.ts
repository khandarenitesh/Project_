export class AppConfiguration {
  Id: number = 0;
  Key: string = '';
  Value: string = '';
  Info: string = '';
  Action: string = '';
}
