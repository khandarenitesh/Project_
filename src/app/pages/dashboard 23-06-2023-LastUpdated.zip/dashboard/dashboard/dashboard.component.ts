import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { AppCode } from '../../app.code';
import { Observable } from 'rxjs';
import { startWith, map } from 'rxjs/operators';
import { DashboardService } from './dashboard.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { AuthService } from '../../modules/auth/services/auth.service';
import {
  ChequeAcctModel, DashbordorderDispatchcountmodel, InventoryCountModel, OrderReturnModel,
  StockTransferModel
} from './dashbordcountmodel.model';
import { ToastrService } from 'ngx-toastr';
import { formatDate } from '@angular/common';
import { ChartData, DashboardModel } from './dashboard-model.model';
import { Chart, registerables } from '../../../../node_modules/chart.js'
import ChartDataLabels from 'chartjs-plugin-datalabels';
import { MatTableDataSource } from '@angular/material/table';
import { OrderDispatchService } from '../../modules/order-dispatch/Services/order-dispatch.service';
import { ChequeAccountingService } from '../../modules/cheque-accounting/Services/cheque-accounting.service';
import { InventoryInwardService } from '../../modules/inventory-inward/Services/inventory-inward.service'

Chart.register(...registerables);
Chart.register(ChartDataLabels);

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss'],
})

export class DashboardComponent implements OnInit {

  dashboardModel: DashboardModel;
  OrderdispatchModulecount: DashbordorderDispatchcountmodel;
  invCount: InventoryCountModel;
  OrderReturncnt: OrderReturnModel;
  cheacctcnt: ChequeAcctModel;
  StockTrsCnt: StockTransferModel;
  submitted: boolean = false;
  DashBoardForm: FormGroup;

  defaultform: any = {
    Company: '',
    Branch: '',
    FromDate: '',
    ToDate: ''
  };

  InvalidCompany: boolean = false;
  InvalidBranch: boolean = false;
  CompanyList: any[] = [];
  BranchList: any[] = [];
  isLoading: boolean = false;
  isLoadingSpinner: boolean = false;
  isLoadingSpinnerOrderDis: boolean = false;
  isLoadingSpinnerCHQ: boolean = false;
  isLoadingSpinnerOrdrRtrn: boolean = false;
  isLoadingSpinnerStckTrns: boolean = false;
  isLoadingSpinnerInvtryInv: boolean = false;
  BranchNameArray: Observable<DashboardModel[]>;
  CompanyNameArray: Observable<DashboardModel[]>;
  FromDate = new FormControl(new Date());
  ToDate = new FormControl(new Date());
  BranchId: number = 0;
  CompId: number = 0;
  UserId: number = 0;
  DashbordsModel: any;
  DataModelCountModel: any;

  // FOR ALL Order Dispatch module
  TodayInv: number = 0;
  TodayInvstockTrnsfr: number = 0;
  TotalInvoices: number = 0;
  CummPL: number = 0;
  OrderDispatchCummPL: number = 0;
  InvPerMonth: number = 0;
  TodaysBoxes: number = 0;
  CummBoxes: number = 0;
  PendingLR: number = 0;
  PendingLRstockTrnsfr: number = 0;
  DispatchN: number = 0;
  DispatchN1: number = 0;
  DispatchN2: number = 0;
  DispatchPending: number = 0;
  SalesAmtToday: number = 0;
  SalesAmtCumm: number = 0;
  NotDispPckdInv: number = 0;
  NotDispPckdBox: number = 0;
  LocalMode: number = 0;
  OtherCity: number = 0;
  ByHand: number = 0;
  CompanyId: number = 0;

  // For All Stock Transfer Count
  CummInvstockTrnsfr: number = 0;
  PendingDispatch: number = 0;
  TodayBox: number = 0;
  CummBox: number = 0;

  // For ALL Inventory inward supervisor
  Totalvehical: number = 0;
  Totalboxes: number = 0;
  Pendingclaim: number = 0;
  PendingSan: number = 0;

  //For ALL Order Return supervisor Counts
  TotalClaims: number = 0;
  TodysCong: number = 0;
  MonthCong: number = 0;
  Warehouse: number = 0;
  Auditorchk: number = 0;
  RecvdAtOPCnt: number = 0;
  SaleableClaim: number = 0;
  SalebleCN1: number = 0;
  SalebleCN2: number = 0;
  SalebleCN2_7: number = 0;
  SalebleCN7Plus: number = 0;
  PendingCN: number = 0;
  SettPeriod15: number = 0;
  SettPeriod30: number = 0;
  SettPeriod45: number = 0;
  SettPeriodMore45: number = 0;

  //For All Cheque Accoounting Operator Count
  TotalChqBounced: number = 0;
  TotalFirstNotice: number = 0;
  TotalLegalNotice: number = 0;
  DepositedDay: number = 0;
  DepositedMonth: number = 0;
  DealyDeposited: number = 0;
  Overduestk: number = 0;
  NTotalFirstNotice: number = 0;
  NTotalLegalNotice: number = 0;
  BranchIdValue: number = 0;
  CurrentDateTime = new Date();
  minDate = new Date();
  maxDate = new Date();

  //chart model
  ChartDataModel: ChartData = new ChartData;

  //Table Data Display
  displayedColumnsForApiFilterList = ['SrNo', 'InvNo', 'NoOfBox', 'InvCreatedDate', 'StockistNo', 'StockistName', 'InvAmount', 'TransportModeId'];
  displayedColumnsForApiFilterOrderReturn = ['SrNo', 'StockistNo', 'StockistName', 'LRNo', 'LRDate', 'TransporterName', 'GatepassNo', 'ClaimNo', 'SalesOrderDate'];
  displayedColumnsForApiFilterchqAcnt = ['SrNo', 'StockistName', 'Date', 'BankName', 'City', 'BankAccountNo', 'ChequeNo', 'ChequeSts', 'DateDiff'];
  displayedColumnsForApiFilterInventoryInwrd = ['SrNo', 'InvNo', 'InvoiceDate', 'LrNo', 'LrDate', 'TransporterName', 'TransporterNo', 'VehicleNo'];


  public DataSource = new MatTableDataSource<any>();
  public DataSourceForLclTrnOtr = new MatTableDataSource<any>();

  //Count related
  InvDataList: any[] = [];
  InvDatalTOList: any[] = [];
  DataModel: any;
  InvoicList: any;
  ModalcountTitle: string = "";
  TodayDateForFilter: any;
  DModel: any;
  CommonDataListforTable: any[] = []
  DataordrreturnList: any[] = [];
  StockTransferData: any[] = [];
  ChequeData: any[] = [];
  InventoryInwrdData: any[] = [];
  DataLoadModel: any;
  currentValue: any;

  //declare datasource for table
  public DataSourceForLRSRSCNforDataOrdrRtrn = new MatTableDataSource<any>();
  public DataSourceForInvPickListStockTrnsfer = new MatTableDataSource<any>();
  public DataSourceChequeData = new MatTableDataSource<any>();
  public DataSourceInveontoryInward = new MatTableDataSource<any>();

  constructor(
    private fb: FormBuilder, private chRef: ChangeDetectorRef, private toaster: ToastrService, private authService: AuthService,
    private _Service: DashboardService, private modalService: NgbModal, private _orderDispatchService: OrderDispatchService,
    private chequeService: ChequeAccountingService, private InvwrdService: InventoryInwardService) {
    this.FromDate = new FormControl(new Date());
    this.ToDate = new FormControl(new Date());
  }

  ngOnInit(): void {
    this.initForm();
    let obj = AppCode.getUser();
    this.BranchId = obj.BranchId;
    this.CompId = obj.CompanyId;
    this.UserId = obj.UserId;
    let RoleId = obj.RoleId;
    this.GetBranchList();
    //get data from aside menu through subject
    this.authService.currentData.subscribe((currentData: any) => {
      this.currentValue = currentData
    });

    var date = new Date();
    this.FromDate = new FormControl(new Date(date.getFullYear(), date.getMonth(), 1));
    this.DataLoadModel = {
      "BranchId": this.BranchId,
      "CompanyId": this.CompId,
      'FromDate': AppCode.createDateAsUTC(this.FromDate.value),
      'ToDate': AppCode.createDateAsUTC(this.ToDate.value)
    }
    this.TodayDateForFilter = formatDate(this.CurrentDateTime, 'yyyy-MM-dd', 'en-US');
    //count api
    this.GetDashboardCount(this.DataLoadModel);
    this.GetInventoryInwardCount(this.DataLoadModel);
    this.GetOrderReturnCount(this.DataLoadModel);
    this.GetChequeAccountingCount(this.DataLoadModel);
    this.GetStockTranscount(this.DataLoadModel);

    // List API
    this.GetInvoiceListforOrderDispatch();
    this.GetLRSRSCNListforFilterDataOrdrRtrn();
    this.GetChequeList();
    this.InventoryInwardlistForFilter()

  }

  //Form Initialization for fetching data from between date
  initForm() {
    this.DashBoardForm = this.fb.group({
      Branch: [
        this.defaultform.Branch,
        Validators.compose([
          Validators.required,
          Validators.maxLength(250),
        ]),
      ],
      Company: [
        this.defaultform.Company,
        Validators.compose([
          Validators.required,
          Validators.maxLength(250),
        ]),
      ]
    });
  }

  get f(): { [key: string]: AbstractControl } {
    return this.DashBoardForm.controls;
  }

  //Get Branch List
  GetBranchList() {
    this._Service.getBranchList_Service(AppCode.allString)
      .subscribe(
        (data: any) => {
          this.BranchList = data;
          this.BranchList = this.BranchList.sort((a: any, b: any) => a.BranchName.localeCompare(b.BranchName));
          this.BranchNameArray = this.f.Branch.valueChanges
            .pipe(
              startWith<string | DashboardModel>(''),
              map(value => typeof value === 'string' ? value : value !== null ? value.BranchName : null),
              map(BranchName => BranchName ? this.filterBranchName(BranchName) : this.BranchList.slice())
            );
          this.chRef.detectChanges();

        },
        (error) => {
          console.error(error);
        }
      );
  }

  //Autocomplete Search Filter
  private filterBranchName(name: string): DashboardModel[] {
    this.InvalidBranch = false;
    const filterValue = name.toLowerCase();
    return this.BranchList.filter((option: any) =>
      option.BranchName.toLowerCase().includes(filterValue));
  }

  // Select or Choose dropdown values
  displayFnBranchName(name: DashboardModel): string {
    return name && name.BranchName ? name.BranchName : '';
  }

  //Validation for branch
  branchValidation() {
    this.submitted = false;
    if ((this.f.Branch.value === null || this.f.Branch.value.BranchId === '' || this.f.Branch.value.BranchId === undefined || this.f.Branch.value.BranchId === null)) {
      this.InvalidBranch = true;
      this.isLoading = false;
      return;
    }
    else {
      this.InvalidBranch = false;
    }
  }

  //on change event
  OnChangeCompany() {
    if ((this.f.Branch.value.BranchId !== "" && this.f.Branch.value.BranchId !== null && this.f.Branch.value.BranchId !== undefined)) {
      this.BranchIdValue = this.f.Branch.value.BranchId;
      this.InvalidBranch = false;
    }
    if (this.InvalidBranch === false) {
      this._Service.getCompanyBranch_Serive(this.BranchIdValue)
        .subscribe(
          (data: any) => {
            this.CompanyList = [];
            this.CompanyList = data;
            this.CompanyNameArray = this.f.Company.valueChanges
              .pipe(
                startWith<string | DashboardModel>(''),
                map(value => typeof value === 'string' ? value : value !== null ? value.CompanyName : null),
                map(CompanyName => CompanyName ? this.filterCompanyName(CompanyName) : this.CompanyList.slice())
              );
            let obj = {
              "CompanyId": data[0].CompanyId,
              "CompanyName": data[0].CompanyName
            }
            this.f.Company.setValue(obj);
            this.chRef.detectChanges();
          },
          (error) => {
            console.error(error);
            this.chRef.detectChanges();
          });
    }

  }

  //Autocomplete Search Filter
  private filterCompanyName(name: string): DashboardModel[] {
    this.InvalidCompany = false;
    const filterValue = name.toLowerCase();
    return this.CompanyList.filter((campny: any) =>
      campny.CompanyName.toLowerCase().includes(filterValue));
  }

  displayFnCompanyName(name: DashboardModel): string {
    return name && name.CompanyName ? name.CompanyName : '';
  }

  //validation for company name
  companyValidation() {
    this.submitted = false;
    if ((this.f.Company.value === '' || this.f.Company.value === undefined || this.f.Company.value === null)) {
      this.InvalidCompany = true;
      this.isLoading = false
      return;
    }
    else {
      this.InvalidCompany = false;
    }
  }

  // Featch Data from between dates
  FeatchData() {
    this.isLoadingSpinner = true;
    this.submitted = true;
    if (this.FromDate.value > this.ToDate.value) {
      this.toaster.warning('To date should be greater than from date!');
      return;
    }
    if (this.UserId == 1) //Superadmin
    {
      if (!this.DashBoardForm.valid) {
        this.InvalidBranch = false;
        this.InvalidCompany = false;
        return;
      }
      else {
        if (this.InvalidBranch === false || this.InvalidCompany === false) {
          this.DataModelCountModel = {
            "BranchId": this.f.Branch.value.BranchId,
            "CompanyId": this.f.Company.value.CompanyId,
            'FromDate': AppCode.createDateAsUTC(this.FromDate.value),
            'ToDate': AppCode.createDateAsUTC(this.ToDate.value)
          };
        }
        else {
          this.toaster.error(AppCode.FailStatus);
          this.isLoadingSpinner = false;
          this.chRef.detectChanges();
        }
      }
    }
    else  // Branchadmin, operator,supervisor
    {
      this.DataModelCountModel = {
        "BranchId": this.BranchId,
        "CompanyId": this.CompId,
        'FromDate': AppCode.createDateAsUTC(this.FromDate.value),
        'ToDate': AppCode.createDateAsUTC(this.ToDate.value)
      };
    }
    this.GetDashboardCount(this.DataModelCountModel);
    this.GetInventoryInwardCount(this.DataModelCountModel);
    this.GetOrderReturnCount(this.DataModelCountModel);
    this.GetChequeAccountingCount(this.DataModelCountModel);
    this.GetStockTranscount(this.DataModelCountModel);
    this.isLoadingSpinner = false;
    this.submitted = false;
    this.chRef.detectChanges();
  }

  //Clear Data
  clear() {
    this.InvalidBranch = false;
    // For Autocomplete this will be use
    // let name = {
    //   "CompanyName": ""
    // }
    // this.f.Company.setValue(name);
    // let name1 = {
    //   "BranchName": ""
    // }
    // this.f.Branch.setValue(name1);
    this.f.Branch.reset();
    this.f.Company.reset();
    this.FromDate = new FormControl(new Date());
    this.ToDate = new FormControl(new Date());
    this.isLoading = false;
    this.submitted = false;
    this.chRef.detectChanges();
  }

  // Open Modal for chart/popup
  OpenModalForChart(content: any, Flag: string, chartId: any) {
    this.ChartDataModel.chartdata = [];   //Empty array initialy
    this.ChartDataModel.Flag = Flag;
    this.DashbordsModel = this.modalService.open(content, {
      centered: true,
      size: this.ChartDataModel.Flag == 'SaleableCreditNote' ? 'lg' : 'md',
      scrollable: true,
      backdrop: 'static'
    });
    this.getDataForAllBarChart(chartId);
    if (Flag == 'TotalInvoicesandpicklist') {
      this.ChartDataModel.ChartModalTitle = "Total Invoices and picklist";
    }
    else if (Flag == 'NoofBoxesandLRupdation') {
      this.ChartDataModel.ChartModalTitle = "No of Boxes and LR updation";
    }
    else if (Flag == 'SalesAmtforthedaytilldate') {
      this.ChartDataModel.ChartModalTitle = "Sales Amount for the day till date";
    }
    else if (Flag == 'NotyetDispatched') {
      this.ChartDataModel.ChartModalTitle = "Not Yet Dispatched";
    }
    else if (Flag == 'Noofboxesdispatched') {
      this.ChartDataModel.ChartModalTitle = "No Of Boxes Dispatched";
    }
    else if (Flag == 'TotalChqBounced') {
      this.ChartDataModel.ChartModalTitle = "Cheque Bounced";
    }
    else if (Flag == 'ChequeDeposited') {
      this.ChartDataModel.ChartModalTitle = 'Cheque Deposited';
    }
    else if (Flag == 'CheqAccNotices') {
      this.ChartDataModel.ChartModalTitle = 'Total Notices';
    }
    else if (Flag == 'TotalInvoicesPicklist') {
      this.ChartDataModel.ChartModalTitle = 'Total Invoices & Picklist';
    }
    else if (Flag == 'NoofBoxesLRUpdation') {
      this.ChartDataModel.ChartModalTitle = 'No of Boxes & LR Updation'
    }
    if (Flag == 'TotalInvoicesandpicklist') {
      this.ChartDataModel.ChartModalTitle = "Total Invoices and picklist";
    }
    else if (Flag == 'TotalDispatch') {
      this.ChartDataModel.ChartModalTitle = "Total Dispatch";
    }
    else if (Flag == 'SalesAmtforthedaytilldate') {
      this.ChartDataModel.ChartModalTitle = "Sales Amount for the day till date";
    }
    else if (Flag == 'NotyetDispatched') {
      this.ChartDataModel.ChartModalTitle = "Not Yet Dispatched";
    }
    else if (Flag == 'ChequeAccounting') {
      this.ChartDataModel.ChartModalTitle = "Cheque Bounced";
    }
    else if (Flag == 'ChequeDeposited') {
      this.ChartDataModel.ChartModalTitle = 'Cheque Deposited';
    }
    else if (Flag == 'BoxesndVehiclesdetails') {
      this.ChartDataModel.ChartModalTitle = 'Boxes and Vehicles details';
    }
    else if (Flag == 'ClaimDetails') {
      this.ChartDataModel.ChartModalTitle = 'Claim Details';
    }
    else if (Flag == 'PendingClaim') {
      this.ChartDataModel.ChartModalTitle = 'Pending Claim';
    }
    else if (Flag == 'SaleableCreditNote') {
      this.ChartDataModel.ChartModalTitle = 'Saleable Credit Note';
    }
    else if (Flag == 'SettlementPeriod') {
      this.ChartDataModel.ChartModalTitle = 'Settlement Period';
    }
    else if (Flag == 'ConsignmentReceived') {
      this.ChartDataModel.ChartModalTitle = 'Consignment Received';
    }
    else if (Flag == 'SRSDetails') {
      this.ChartDataModel.ChartModalTitle = 'SRS Details';
    }
  }

  //Get Data For Chart
  getDataForAllBarChart(ChartId: any) {
    this.isLoading = true;
    this.ChartDataModel.chartdata = [];
    if (ChartId === 'TtlInvNdPklstBarChart') { //1
      //get Id from template for the chart
      this.ChartDataModel.ChartId = document.getElementById('barchart');
      //get Count Data from count function for the chart
      this.ChartDataModel.ChartDataArray = this.OrderdispatchModulecount;
      if (this.ChartDataModel.ChartDataArray !== null && this.ChartDataModel.ChartDataArray !== undefined) {
        this.ChartDataModel.DataModel = {
          'Total Invoices': this.ChartDataModel.ChartDataArray.TodayInv,
          'Cumm Invoices': this.ChartDataModel.ChartDataArray.InvPerMonth,
          'Cumm Picklist': this.ChartDataModel.ChartDataArray.CummPL
        }
        //convert data object to array format.
        this.ChartDataModel.ObjectToArray = Object.values(this.ChartDataModel.DataModel);
        //push data object into array.
        this.ChartDataModel.chartdata.push(this.ChartDataModel.ObjectToArray);
        //function call or send a data to function for the chart rendering.
        this.RenderDataForBarChart(this.ChartDataModel.ObjectToArray, this.ChartDataModel.BarChartType, this.ChartDataModel.ChartId, this.ChartDataModel.TotalInvoicesandpicklistLabel);
      }
    }
    else if (ChartId === 'NoofBoxesandLRupdationBarChart') { //2
      //geting Id from template for the chart.
      this.ChartDataModel.ChartId = document.getElementById('barchart');
      //get Count Data from count function for the chart.
      this.ChartDataModel.ChartDataArray = this.OrderdispatchModulecount;
      if (this.ChartDataModel.ChartDataArray !== null && this.ChartDataModel.ChartDataArray !== undefined) {
        this.ChartDataModel.DataModel = {
          'Today Sales': this.ChartDataModel.ChartDataArray.TodaysBoxes,
          'Cumm sale month': this.ChartDataModel.ChartDataArray.CummBoxes,
          'Pending LR Updation': this.ChartDataModel.ChartDataArray.PendingLR
        }

        //convert data object to array format.
        this.ChartDataModel.ObjectToArray = Object.values(this.ChartDataModel.DataModel);
        //push data object into array.
        this.ChartDataModel.chartdata.push(this.ChartDataModel.ObjectToArray);
        //function call or send a data to function for the chart rendering.
        this.RenderDataForBarChart(this.ChartDataModel.ObjectToArray, this.ChartDataModel.BarChartType, this.ChartDataModel.ChartId, this.ChartDataModel.NoofBoxesandLRupdationLabel);
      }
    }
    else if (ChartId === 'TotalDispatchBarChart') { //3
      //geting Id from template for chart.
      this.ChartDataModel.ChartId = document.getElementById('barchart');
      //get Count Data from count function for the chart
      this.ChartDataModel.ChartDataArray = this.OrderdispatchModulecount;
      if (this.ChartDataModel.ChartDataArray !== undefined && this.ChartDataModel.ChartDataArray !== null) {
        this.ChartDataModel.DataModel = {
          'N1': this.ChartDataModel.ChartDataArray.DispatchN,
          'N2': this.ChartDataModel.ChartDataArray.DispatchN1,
          'N3': this.ChartDataModel.ChartDataArray.DispatchN2,
          'Dispatch Pending': this.ChartDataModel.ChartDataArray.DispatchPending
        }
        //convert data object to array format.
        this.ChartDataModel.ObjectToArray = Object.values(this.ChartDataModel.DataModel);
        //push data object into array.
        this.ChartDataModel.chartdata.push(this.ChartDataModel.ObjectToArray);
        //function call or send a data to function for the chart rendering.
        this.RenderDataForBarChart(this.ChartDataModel.ObjectToArray, this.ChartDataModel.BarChartType, this.ChartDataModel.ChartId, this.ChartDataModel.TotalDispatchLabel);
      }
    }
    else if (ChartId === 'SalesAmtforthedaytilldateBarChart') {   //4
      //geting Id from template for chart.
      this.ChartDataModel.ChartId = document.getElementById('barchart');
      //get Count Data from count function for the chart.
      this.ChartDataModel.ChartDataArray = this.OrderdispatchModulecount;
      if (this.ChartDataModel.ChartDataArray !== undefined && this.ChartDataModel.ChartDataArray !== null) {
        this.ChartDataModel.DataModel = {
          'Sales Today': this.ChartDataModel.ChartDataArray.SalesAmtToday,
          'Cumm sale month': this.ChartDataModel.ChartDataArray.SalesAmtCumm
        }
        //convert data object to array format.
        this.ChartDataModel.ObjectToArray = Object.values(this.ChartDataModel.DataModel);
        //push data object into array.
        this.ChartDataModel.chartdata.push(this.ChartDataModel.ObjectToArray);
        //function call or send a data to function for the chart rendering.
        this.RenderDataForBarChart(this.ChartDataModel.ObjectToArray, this.ChartDataModel.BarChartType, this.ChartDataModel.ChartId, this.ChartDataModel.SalesAmtforthedaytilldate);
      }
    }
    else if (ChartId === 'NotyetDispatchedBarChart') {  //5
      //geting Id from template for chart.
      this.ChartDataModel.ChartId = document.getElementById('barchart');
      //get Count Data from count function for the chart.
      this.ChartDataModel.ChartDataArray = this.OrderdispatchModulecount;
      if (this.ChartDataModel.ChartDataArray !== undefined && this.ChartDataModel.ChartDataArray !== null) {
        this.ChartDataModel.DataModel = {
          'packed Invoice': this.ChartDataModel.ChartDataArray.NotDispPckdInv,
          'packed boxes': this.ChartDataModel.ChartDataArray.NotDispPckdBox,
        }
        //convert data object to array format.
        this.ChartDataModel.ObjectToArray = Object.values(this.ChartDataModel.DataModel);
        //push data object into array.
        this.ChartDataModel.chartdata.push(this.ChartDataModel.ObjectToArray);
        //function call or send a data to function for the chart rendering.
        this.RenderDataForBarChart(this.ChartDataModel.ObjectToArray, this.ChartDataModel.BarChartType, this.ChartDataModel.ChartId, this.ChartDataModel.NotyetDispatchedLabel);
      }
    }
    else if (ChartId === 'NoofboxesdispatchePieChart') {  //6
      //geting Id from template for chart.
      this.ChartDataModel.ChartId = document.getElementById('piechart');
      //get Count Data from count function for the chart.
      this.ChartDataModel.ChartDataArray = this.OrderdispatchModulecount;
      if (this.ChartDataModel.ChartDataArray !== undefined && this.ChartDataModel.ChartDataArray !== null) {
        this.ChartDataModel.DataModel = {
          'Local': this.ChartDataModel.ChartDataArray.LocalMode,
          'Other City': this.ChartDataModel.ChartDataArray.OtherCity,
          'By Hand': this.ChartDataModel.ChartDataArray.ByHand,
        }
        //convert data object to array format.
        this.ChartDataModel.ObjectToArray = Object.values(this.ChartDataModel.DataModel);
        //push data object into array.
        this.ChartDataModel.chartdata.push(this.ChartDataModel.ObjectToArray);
        //function call or send a data to function for the chart rendering.
        this.RenderingDataForPieChart(this.ChartDataModel.ObjectToArray, this.ChartDataModel.PieChartType, this.ChartDataModel.ChartId,
          this.ChartDataModel.NoofboxesdispatcheLabel);
      }
    }
    //Order Dispatch chart End.

    //Inventory Inward Start
    else if (ChartId === 'InventoryInwardBarChart') {  //7
      //geting Id from template for chart.
      this.ChartDataModel.ChartId = document.getElementById('barchart');
      //get Count Data from count function for the chart.
      this.ChartDataModel.ChartDataArray = this.invCount;
      if (this.ChartDataModel.ChartDataArray !== undefined && this.ChartDataModel.ChartDataArray !== null) {
        this.ChartDataModel.DataModel = {
          'Total Vehicle': this.ChartDataModel.ChartDataArray.Totalvehical,
          'No of Boxes': this.ChartDataModel.ChartDataArray.Totalboxes
        }
        //convert data object to array format.
        this.ChartDataModel.ObjectToArray = Object.values(this.ChartDataModel.DataModel);
        //push data object into array.
        this.ChartDataModel.chartdata.push(this.ChartDataModel.ObjectToArray);
        //function call or send a data to function for the chart rendering.
        this.RenderDataForBarChart(this.ChartDataModel.ObjectToArray, this.ChartDataModel.BarChartType, this.ChartDataModel.ChartId, this.ChartDataModel.InventoryInwardLabel);
      }
    }
    else if (ChartId === 'ClaimDetailsPieChart') {  //8
      //geting Id from template for chart.
      this.ChartDataModel.ChartId = document.getElementById('piechart');
      //get Count Data from count function for the chart.
      this.ChartDataModel.ChartDataArray = this.invCount;
      if (this.ChartDataModel.ChartDataArray !== undefined && this.ChartDataModel.ChartDataArray !== null) {
        this.ChartDataModel.DataModel = {
          'Pending Claim': this.ChartDataModel.ChartDataArray.Pendingclaim,
          'Pending SAN': this.ChartDataModel.ChartDataArray.PendingSan,
        }
        //convert data object to array format.
        this.ChartDataModel.ObjectToArray = Object.values(this.ChartDataModel.DataModel);
        //push data object into array.
        this.ChartDataModel.chartdata.push(this.ChartDataModel.ObjectToArray);
        //function call or send a data to function for the chart rendering.
        this.RenderingDataForPieChart(this.ChartDataModel.ObjectToArray, this.ChartDataModel.PieChartType, this.ChartDataModel.ChartId,
          this.ChartDataModel.ClaimDetailsPieChartLabel);
      }
    }

    else if (ChartId === 'PendingClaimPieChart') {  //9
      //geting Id from template for chart.
      this.ChartDataModel.ChartId = document.getElementById('piechart');
      //get Count Data from count function for the chart.
      this.ChartDataModel.ChartDataArray = this.OrderReturncnt;
      if (this.ChartDataModel.ChartDataArray !== undefined && this.ChartDataModel.ChartDataArray !== null) {
        this.ChartDataModel.DataModel = {
          'Total': this.ChartDataModel.ChartDataArray.TotalClaims,
          'Ware House': this.ChartDataModel.ChartDataArray.Warehouse,
          'Auditor Check': this.ChartDataModel.ChartDataArray.Auditorchk,
          'Operator End': this.ChartDataModel.ChartDataArray.RecvdAtOPCnt,
          'Saleable Claim': this.ChartDataModel.ChartDataArray.SaleableClaim,
        }
        //convert data object to array format.
        this.ChartDataModel.ObjectToArray = Object.values(this.ChartDataModel.DataModel);
        //push data object into array.
        this.ChartDataModel.chartdata.push(this.ChartDataModel.ObjectToArray);
        //function call or send a data to function for the chart rendering.
        this.RenderingDataForPieChart(this.ChartDataModel.ObjectToArray, this.ChartDataModel.PieChartType, this.ChartDataModel.ChartId,
          this.ChartDataModel.PendingClaimPieChartLabel);
      }
    }
    else if (ChartId === 'SaleableCreditNoteBarChart') {   //10
      //geting Id from template for chart.
      this.ChartDataModel.ChartId = document.getElementById('barchart');
      //get Count Data from count function for the chart.
      this.ChartDataModel.ChartDataArray = this.OrderReturncnt;
      if (this.ChartDataModel.ChartDataArray !== undefined && this.ChartDataModel.ChartDataArray !== null && this.ChartDataModel.ChartDataArray !== "") {
        this.ChartDataModel.DataModel = {
          'One days': this.ChartDataModel.ChartDataArray.SalebleCN1,
          'two days': this.ChartDataModel.ChartDataArray.SalebleCN2,
          'more then 2 days': this.ChartDataModel.ChartDataArray.SalebleCN2_7,
          'more 7 days': this.ChartDataModel.ChartDataArray.SalebleCN7Plus,
          'Pending CN': this.ChartDataModel.ChartDataArray.PendingCN,
        }
        //convert data object to array format.
        this.ChartDataModel.ObjectToArray = Object.values(this.ChartDataModel.DataModel);
        //push data object into array.
        this.ChartDataModel.chartdata.push(this.ChartDataModel.ObjectToArray);
        //function call or send a data to function for the chart rendering.
        this.RenderDataForBarChart(this.ChartDataModel.ObjectToArray, this.ChartDataModel.BarChartType, this.ChartDataModel.ChartId, this.ChartDataModel.SaleableCreditNoteLabel);
      }
    }
    else if (ChartId === 'SettlementPeriodBarChart') {   //11
      //geting Id from template for chart.
      this.ChartDataModel.ChartId = document.getElementById('barchart');
      //get Count Data from count function for the chart.
      this.ChartDataModel.ChartDataArray = this.OrderReturncnt;
      if (this.ChartDataModel.ChartDataArray !== undefined && this.ChartDataModel.ChartDataArray !== null) {
        this.ChartDataModel.DataModel = {
          '15 Days': this.ChartDataModel.ChartDataArray.SettPeriod15,
          '30 Days': this.ChartDataModel.ChartDataArray.SettPeriod30,
          '45 Days': this.ChartDataModel.ChartDataArray.SettPeriod45,
          'above 45 Days': this.ChartDataModel.ChartDataArray.SettPeriodMore45
        }
        //convert data object to array format.
        this.ChartDataModel.ObjectToArray = Object.values(this.ChartDataModel.DataModel);
        //push data object into array.
        this.ChartDataModel.chartdata.push(this.ChartDataModel.ObjectToArray);
        //function call or send a data to function for the chart rendering.
        this.RenderDataForBarChart(this.ChartDataModel.ObjectToArray, this.ChartDataModel.BarChartType, this.ChartDataModel.ChartId, this.ChartDataModel.SettlementPeriodLabel);
      }
    }
    else if (ChartId === 'ConsignmentReceivedPieChart') {
      //geting Id from template for chart.
      this.ChartDataModel.ChartId = document.getElementById('piechart');
      //get Count Data from count function for the chart.
      this.ChartDataModel.ChartDataArray = this.OrderReturncnt;
      if (this.ChartDataModel.ChartDataArray !== undefined && this.ChartDataModel.ChartDataArray !== null) {
        this.ChartDataModel.DataModel = {
          'Todys Consignment': this.ChartDataModel.ChartDataArray.TodysCong,
          'MonthCong': this.ChartDataModel.ChartDataArray.MonthCong,
        }
        //convert data object to array format.
        this.ChartDataModel.ObjectToArray = Object.values(this.ChartDataModel.DataModel);
        //push data object into array.
        this.ChartDataModel.chartdata.push(this.ChartDataModel.ObjectToArray);
        //function call or send a data to function for the chart rendering.
        this.RenderingDataForPieChart(this.ChartDataModel.ObjectToArray, this.ChartDataModel.PieChartType, this.ChartDataModel.ChartId, this.ChartDataModel.ConsignmentReceivedLabel);
      }
    }

    else if (ChartId === 'TotalChqBouncedBarChart') {
      this.ChartDataModel.ChartId = document.getElementById('barchart');
      this.ChartDataModel.ChartDataArray = this.cheacctcnt;
      if (this.ChartDataModel.ChartDataArray !== undefined && this.ChartDataModel.ChartDataArray !== null) {
        this.ChartDataModel.DataModel = {
          'Total Cheque Bounced': this.ChartDataModel.ChartDataArray.TotalChqBounced,
          'Total First Notice': this.ChartDataModel.ChartDataArray.TotalFirstNotice,
          'Total Legal Notice': this.ChartDataModel.ChartDataArray.TotalLegalNotice
        }
        this.ChartDataModel.ObjectToArray = Object.values(this.ChartDataModel.DataModel);
        this.ChartDataModel.chartdata.push(this.ChartDataModel.ObjectToArray);
        this.RenderDataForBarChart(this.ChartDataModel.ObjectToArray, this.ChartDataModel.BarChartType, this.ChartDataModel.ChartId, this.ChartDataModel.ChequeBouncedLabel);
        this.chRef.detectChanges();
      }
    }
    else if (ChartId === 'ChequeDepositedBarChart') {
      this.ChartDataModel.ChartId = document.getElementById('barchart');
      this.ChartDataModel.ChartDataArray = this.cheacctcnt;
      if (this.ChartDataModel.ChartDataArray !== undefined && this.ChartDataModel.ChartDataArray !== null) {
        this.ChartDataModel.DataModel = {
          'Deposited Day': this.ChartDataModel.ChartDataArray.DepositedDay,
          'Deposited Month': this.ChartDataModel.ChartDataArray.DepositedMonth,
          'Dealy Deposited': this.ChartDataModel.ChartDataArray.DealyDeposited,
          'Over due stokist': this.ChartDataModel.ChartDataArray.Overduestk
        }
        this.ChartDataModel.ObjectToArray = Object.values(this.ChartDataModel.DataModel);
        this.ChartDataModel.chartdata.push(this.ChartDataModel.DataModel);
        this.RenderDataForBarChart(this.ChartDataModel.ObjectToArray, this.ChartDataModel.BarChartType, this.ChartDataModel.ChartId, this.ChartDataModel.ChequeDepositedLabel);
        this.chRef.detectChanges();
      }
    }
    else if (ChartId === 'CheqAccNoticesPieChart') {
      this.ChartDataModel.ChartId = document.getElementById('piechart');
      this.ChartDataModel.ChartDataArray = this.cheacctcnt;
      if (this.ChartDataModel.ChartDataArray !== undefined && this.ChartDataModel.ChartDataArray !== null) {
        this.ChartDataModel.DataModel = {
          'Total First Notice': this.ChartDataModel.ChartDataArray.TotalFirstNotice,
          'Total Legal Notice': this.ChartDataModel.ChartDataArray.TotalLegalNotice
        }
        this.ChartDataModel.ObjectToArray = Object.values(this.ChartDataModel.DataModel);
        this.ChartDataModel.chartdata.push(this.ChartDataModel.ObjectToArray);
        this.RenderingDataForPieChart(this.ChartDataModel.ObjectToArray, this.ChartDataModel.PieChartType, this.ChartDataModel.ChartId, this.ChartDataModel.CheqAccNoticesPieChartLabel);
        this.chRef.detectChanges();
      }
    }
    else if (ChartId === 'TotalInvoicesPicklistPieChart') {
      this.ChartDataModel.ChartId = document.getElementById('piechart');
      this.ChartDataModel.ChartDataArray = this.StockTrsCnt;
      if (this.ChartDataModel.ChartDataArray !== undefined && this.ChartDataModel.ChartDataArray !== null) {
        this.ChartDataModel.DataModel = {
          'Invoices/Day': this.ChartDataModel.ChartDataArray.TodayInvstockTrnsfr,
          'Invoices/Month': this.ChartDataModel.ChartDataArray.CummInvstockTrnsfr,
          'Total Picklist': this.ChartDataModel.ChartDataArray.CummPL,
          'Pending dispatch': this.ChartDataModel.ChartDataArray.PendingDispatch
        }
        this.ChartDataModel.ObjectToArray = Object.values(this.ChartDataModel.DataModel);
        this.ChartDataModel.chartdata.push(this.ChartDataModel.ObjectToArray);
        this.RenderingDataForPieChart(this.ChartDataModel.ObjectToArray, this.ChartDataModel.PieChartType, this.ChartDataModel.ChartId, this.ChartDataModel.StockTransPieChartLabel);
        this.chRef.detectChanges();
      }
    }
    else if (ChartId == 'NoofBoxesLRUpdationBarChart') {
      this.ChartDataModel.ChartId = document.getElementById('barchart');
      this.ChartDataModel.ChartDataArray = this.StockTrsCnt;
      if (this.ChartDataModel.ChartDataArray !== undefined && this.ChartDataModel.ChartDataArray !== null) {
        this.ChartDataModel.DataModel = {
          'Todays Boxes': this.ChartDataModel.ChartDataArray.TodayBox,
          'Cumm Boxes/Month': this.ChartDataModel.ChartDataArray.CummBox,
          'Pending LR Updation': this.ChartDataModel.ChartDataArray.PendingLRstockTrnsfr
        }
        this.ChartDataModel.ObjectToArray = Object.values(this.ChartDataModel.DataModel);
        this.ChartDataModel.chartdata.push(this.ChartDataModel.DataModel);
        this.RenderDataForBarChart(this.ChartDataModel.ObjectToArray, this.ChartDataModel.BarChartType, this.ChartDataModel.ChartId, this.ChartDataModel.NoofBoxesLRUpdationLabel);
        this.chRef.detectChanges();
      }
    }

    else if (ChartId === 'SRSDetailspieChart') {
      this.ChartDataModel.ChartId = document.getElementById('piechart');
      this.ChartDataModel.ChartDataArray = this.OrderReturncnt;
      if (this.ChartDataModel.ChartDataArray !== undefined && this.ChartDataModel.ChartDataArray !== null) {
        this.ChartDataModel.DataModel = {
          'Pending SRS': this.ChartDataModel.ChartDataArray.PendingSRS,
          'Pending CN': this.ChartDataModel.ChartDataArray.PendingCN,
          'Pending Auditor chk': this.ChartDataModel.ChartDataArray.Auditorchk,
        }
        this.ChartDataModel.ObjectToArray = Object.values(this.ChartDataModel.DataModel);
        this.ChartDataModel.chartdata.push(this.ChartDataModel.ObjectToArray);
        this.RenderingDataForPieChart(this.ChartDataModel.ObjectToArray, this.ChartDataModel.PieChartType, this.ChartDataModel.ChartId, this.ChartDataModel.SRSDetailsLabel);
        this.chRef.detectChanges();
      }
    }
    this.isLoading = false;
    this.chRef.detectChanges();
  }

  //Rendering bar chart Data
  RenderDataForBarChart(RealDataShowOnchart: any, ChartType: any, ChartId: any, BarChartLabel: any) {
    if (ChartId !== null || ChartId !== undefined || ChartId !== "") {
      new Chart(ChartId, {
        plugins: [ChartDataLabels],
        type: ChartType,
        data: {
          labels: BarChartLabel,
          datasets: [{
            label: 'dataset',
            data: RealDataShowOnchart,
            backgroundColor: [
              'rgba(255, 99, 132, 0.2)',
              'rgba(255, 159, 64, 0.2)',
              'rgba(255, 205, 86, 0.2)',
              'rgba(75, 192, 192, 0.2)',
              'rgba(54, 162, 235, 0.2)',
              'rgba(153, 102, 255, 0.2)',
              'rgba(201, 203, 207, 0.2)'],
            borderColor: [
              'rgb(255, 99, 132)',
              'rgb(255, 159, 64)',
              'rgb(255, 205, 86)',
              'rgb(75, 192, 192)',
              'rgb(54, 162, 235)',
              'rgb(153, 102, 255)',
              'rgb(201, 203, 207)'
            ],
            borderWidth: 1,
            barPercentage: 0.5,
          }],
        },
        options: {
          responsive: true,
          maintainAspectRation: true,
          scales: {
            y: {
              beginAtZero: true,
            },
          },
          plugins: {
            datalabels: {
              anchor: 'Inbetween',
              align: 'center',
              color: 'black',
              font: {
                weight: 'bold',
                size: 12,
              }
            },
            legend: {
              display: false // This hides all text in the legend and also the labels.
            }
          }
        }
      });
    }
  }

  //Rendering Pie Chart Data
  RenderingDataForPieChart(RealDataShowOnchart: any, ChartType: any, ChartId: any, ChartLabel: any) {
    if (ChartId !== null || ChartId !== undefined || ChartId !== "") {
      new Chart(ChartId, {
        type: ChartType,
        data: {
          labels: ChartLabel,
          datasets: [{
            data: RealDataShowOnchart,
            backgroundColor: [
              'rgb(255, 99, 132)',
              'rgb(255, 159, 64)',
              'rgb(255, 205, 86)',
              'rgb(75, 192, 192)',
              'rgb(54, 162, 235)',
              'rgb(153, 102, 255)',
              'rgb(201, 203, 207)',
              'rgb(261, 253, 207)',
              'rgb(261, 144, 155)'],
            hoverOffset: 4,
          }]
        },
        options: {
          showDatapoints: true,
          animation: {
            animateScale: true,
            animateRotate: true,
          },
          plugins: {
            legend: {
              display: true, // This hides all text in the legend and also the labels If false.
              position: 'top',
              labels: {
                generateLabels: (chart: any) => {  //get a dynamic value for the labels
                  const datasets = chart.data.datasets;
                  return datasets[0].data.map((data: any, i: any) => ({
                    text: `${chart.data.labels[i]} ${data}`,
                    fillStyle: datasets[0].backgroundColor[i],
                    index: i,
                  }));
                }
              }
            },
            datalabels: {
              // formatter: (val:any,context:any)=> {
              //   for(let i = 0; i <= context.chart.data.datasets.length; i++){
              //     return context.chart.data.labels[context.dataIndex] + ' : ' + JSON.stringify(context.chart.data.datasets[i].data[i])
              //   }
              // },
              color: 'black',
              font: {
                weight: 'bold',
                size: 12,
              }
            }
          },
        }
      });
    }
  }

  //Onclick cross icon for new instance
  OnClickCross() {
    this.InvoicList = [];
    this.CommonDataListforTable = [];
    this.DataSourceForLRSRSCNforDataOrdrRtrn = new MatTableDataSource();
    this.DataSourceInveontoryInward = new MatTableDataSource();
    this.DataSourceChequeData = new MatTableDataSource();
    this.DataSourceForInvPickListStockTrnsfer = new MatTableDataSource();
    this.DataSource = new MatTableDataSource();
    this.modalService.dismissAll();
  }

  // Order Dispatch Supervisor count
  GetDashboardCount(DataModelCount: any) {
    this.isLoading = true;
    this._Service.GetOrderDisCount(DataModelCount)
      .subscribe((data: any) => {
        if (data !== null && data !== undefined && data !== "") {
          this.afterCount(data);
        }
      }, (error: any) => {
        console.error("Error:  " + JSON.stringify(error));
        this.isLoading = false;
        this.chRef.detectChanges();
      });
  }

  // DashBorad Normal Count
  afterCount(data: DashbordorderDispatchcountmodel) {
    this.OrderdispatchModulecount = new DashbordorderDispatchcountmodel();
    this.OrderdispatchModulecount = data;
    this.TodayInv = this.OrderdispatchModulecount.TodayInv;
    this.TotalInvoices = this.OrderdispatchModulecount.TotalInvoices;
    this.OrderDispatchCummPL = this.OrderdispatchModulecount.CummPL;
    this.InvPerMonth = this.OrderdispatchModulecount.InvPerMonth;
    this.TodaysBoxes = this.OrderdispatchModulecount.TodaysBoxes;
    this.CummBoxes = this.OrderdispatchModulecount.CummBoxes;
    this.PendingLR = this.OrderdispatchModulecount.PendingLR;
    this.DispatchN = this.OrderdispatchModulecount.DispatchN;
    this.DispatchN1 = this.OrderdispatchModulecount.DispatchN1;
    this.DispatchN2 = this.OrderdispatchModulecount.DispatchN2;
    this.DispatchPending = this.OrderdispatchModulecount.DispatchPending;
    this.SalesAmtToday = this.OrderdispatchModulecount.SalesAmtToday;
    this.SalesAmtCumm = this.OrderdispatchModulecount.SalesAmtCumm;
    this.NotDispPckdInv = this.OrderdispatchModulecount.NotDispPckdInv;
    this.NotDispPckdBox = this.OrderdispatchModulecount.NotDispPckdBox;
    this.LocalMode = this.OrderdispatchModulecount.LocalMode;
    this.OtherCity = this.OrderdispatchModulecount.OtherCity;
    this.ByHand = this.OrderdispatchModulecount.ByHand;
    this.chRef.detectChanges();
  }

  //Get Inventory Inward All Count
  GetInventoryInwardCount(DataModelCount: any) {
    this.isLoading = true;
    this._Service.GetInvenInwardCount(DataModelCount)
      .subscribe((data: any) => {
        if (data !== null && data !== undefined && data !== "") {
          this.afterCountforInven(data);
        }
      }, (error: any) => {
        console.error("Error: " + JSON.stringify(error));
        this.isLoading = false;
        this.chRef.detectChanges();
      })
  }

  afterCountforInven(data: InventoryCountModel) {
    this.invCount = new InventoryCountModel();
    this.invCount = data;
    this.Totalvehical = this.invCount.Totalvehical;
    this.Totalboxes = this.invCount.Totalboxes;
    this.Pendingclaim = this.invCount.Pendingclaim;
    this.PendingSan = this.invCount.PendingSan
    this.chRef.detectChanges();
  }

  //Get Order Return All Count
  GetOrderReturnCount(DataModelCount: any) {
    this.isLoading = true;
    this._Service.GetOrderreturnDashbord(DataModelCount)
      .subscribe((data: any) => {
        if (data !== null && data !== undefined && data !== "") {
          this.afterCountforOrderReturn(data);
        }
      }, (error: any) => {
        console.error("Error: " + JSON.stringify(error));
        this.isLoading = false;
        this.chRef.detectChanges();
      })
  }

  //Get after Count Order Return All
  afterCountforOrderReturn(data: OrderReturnModel) {
    this.OrderReturncnt = new OrderReturnModel();
    this.OrderReturncnt = data;
    this.TotalClaims = this.OrderReturncnt.TotalClaims;
    this.Warehouse = this.OrderReturncnt.Warehouse;
    this.Auditorchk = this.OrderReturncnt.Auditorchk;
    this.RecvdAtOPCnt = this.OrderReturncnt.RecvdAtOPCnt;
    this.SaleableClaim = this.OrderReturncnt.SaleableClaim;
    this.TodysCong = this.OrderReturncnt.TodysCong;
    this.MonthCong = this.OrderReturncnt.MonthCong;
    this.SalebleCN1 = this.OrderReturncnt.SalebleCN1;
    this.SalebleCN2 = this.OrderReturncnt.SalebleCN2;
    this.SalebleCN2_7 = this.OrderReturncnt.SalebleCN2_7;
    this.SalebleCN7Plus = this.OrderReturncnt.SalebleCN7Plus;
    this.PendingCN = this.OrderReturncnt.PendingCN;
    this.SettPeriod15 = this.OrderReturncnt.SettPeriod15;
    this.SettPeriod30 = this.OrderReturncnt.SettPeriod30;
    this.SettPeriod45 = this.OrderReturncnt.SettPeriod45;
    this.SettPeriodMore45 = this.OrderReturncnt.SettPeriodMore45;
    this.chRef.detectChanges();
  }

  //Get Cheque Accounting All Count
  GetChequeAccountingCount(DataModelCount: any) {
    this.isLoading = true;
    this._Service.GetChequeAccountingDashbord(DataModelCount)
      .subscribe((data: any) => {
        if (data !== null && data !== undefined && data !== "") {
          this.afterCountforChequeAcc(data);
        }
      }, (error: any) => {
        console.error("Error:" + JSON.stringify(error));
        this.isLoading = false;
        this.chRef.detectChanges();
      })

  }

  afterCountforChequeAcc(data: ChequeAcctModel) {
    this.cheacctcnt = new ChequeAcctModel();
    this.cheacctcnt = data;
    this.TotalChqBounced = this.cheacctcnt.TotalChqBounced;
    this.TotalFirstNotice = this.cheacctcnt.TotalFirstNotice;
    this.TotalLegalNotice = this.cheacctcnt.TotalLegalNotice;
    this.DepositedDay = this.cheacctcnt.DepositedDay;
    this.DepositedMonth = this.cheacctcnt.DepositedMonth;
    this.DealyDeposited = this.cheacctcnt.DealyDeposited;
    this.Overduestk = this.cheacctcnt.Overduestk;
    this.NTotalFirstNotice = this.cheacctcnt.NTotalFirstNotice;
    this.NTotalLegalNotice = this.cheacctcnt.NTotalLegalNotice;
    this.chRef.detectChanges();
  }
  //Get Stock Transfer Model Count
  GetStockTranscount(DataModelCount: any) {
    this.isLoading = true;
    this._Service.GetstocktransferCountdashbord(DataModelCount)
      .subscribe((data: any) => {
        if (data !== null && data !== undefined && data !== "") {
          this.afterCountStockTransfer(data);
        }
      }, (error: any) => {
        console.error("Error : " + JSON.stringify(error));
        this.isLoading = false;
        this.chRef.detectChanges();
      })
  }

  afterCountStockTransfer(data: StockTransferModel) {
    this.StockTrsCnt = new StockTransferModel();
    this.StockTrsCnt = data;
    this.TodayInvstockTrnsfr = this.StockTrsCnt.TodayInvstockTrnsfr,
      this.CummInvstockTrnsfr = this.StockTrsCnt.CummInvstockTrnsfr,
      this.CummPL = this.StockTrsCnt.CummPL,
      this.PendingDispatch = this.StockTrsCnt.PendingDispatch,
      this.TodayBox = this.StockTrsCnt.TodayBox,
      this.CummBox = this.StockTrsCnt.CummBox,
      this.PendingLRstockTrnsfr = this.StockTrsCnt.PendingLRstockTrnsfr,
      this.chRef.detectChanges();
  }

  //get Inoice Header List
  GetInvoiceListforOrderDispatch() {
    this.isLoadingSpinnerOrderDis = true;
    var FromDate = new FormControl(formatDate(this.FromDate.value, 'yyyy-MM-dd', 'en-US'));
    var ToDate = new FormControl(formatDate(this.ToDate.value, 'yyyy-MM-dd', 'en-US'));
    this._orderDispatchService.getDashboardInvoice_Service(this.BranchId, this.CompId, FromDate.value, ToDate.value).subscribe((data: any) => {
      if (data.length > 0) {
        this.InvDataList = data;
      } else {
        this.DataSource.data = [];
      }
      this.isLoadingSpinnerOrderDis = false;
      this.chRef.detectChanges();
      (error: any) => {
        console.log(error);
        this.isLoadingSpinnerOrderDis = false;
        this.chRef.detectChanges();
      }
    });
  }

  //Get Order Return List
  GetLRSRSCNListforFilterDataOrdrRtrn() {
    this.isLoadingSpinnerOrdrRtrn = true;
    var FromDate = new FormControl(formatDate(this.FromDate.value, 'yyyy-MM-dd', 'en-US'));
    var ToDate = new FormControl(formatDate(this.ToDate.value, 'yyyy-MM-dd', 'en-US'));
    this._orderDispatchService.GetLRSRSCNListforFilterDataOrdrRtrn_service(this.BranchId, this.CompId, FromDate.value, ToDate.value).subscribe((data: any) => {
      if (data.length > 0) {
        this.DataordrreturnList = data;
      } else {
        this.DataSourceForLRSRSCNforDataOrdrRtrn.data = [];
      }
      this.isLoadingSpinnerOrdrRtrn = false;
      this.chRef.detectChanges();
      (error: any) => {
        console.log(error);
        this.isLoadingSpinnerOrdrRtrn = false;
        this.chRef.detectChanges();
      }
    });
  }

  //Get Cheques List
  GetChequeList() {
    this.isLoadingSpinnerCHQ = true;
    var FromDate = new FormControl(formatDate(this.FromDate.value, 'yyyy-MM-dd', 'en-US'));
    var ToDate = new FormControl(formatDate(this.ToDate.value, 'yyyy-MM-dd', 'en-US'));
    this.chequeService.getDashBoardChequeList_Service(this.BranchId, this.CompId, FromDate.value, ToDate.value).subscribe((data: any) => {
      if (data > 0) {
        this.ChequeData = data;
      } else {
        this.DataSourceChequeData.data = [];
        this.ChequeData = [];
      }
      this.isLoadingSpinnerCHQ = false;
      this.chRef.detectChanges();
    });
  }

  //Get Inveontory Inward list
  InventoryInwardlistForFilter() {
    var FromDate = new FormControl(formatDate(this.FromDate.value, 'yyyy-MM-dd', 'en-US'));
    var ToDate = new FormControl(formatDate(this.ToDate.value, 'yyyy-MM-dd', 'en-US'));
    this.isLoadingSpinnerInvtryInv = true;
    this.InvwrdService.InventoryInwardlistForFilter_Service(this.BranchId, this.CompId, FromDate.value, ToDate.value).subscribe((data: any) => {
      if (data.length > 0) {
        this.InventoryInwrdData = data;
        this.isLoadingSpinnerInvtryInv = false;
      } else {
        this.DataSourceInveontoryInward.data = [];
        this.InventoryInwrdData = [];
      }
      this.isLoadingSpinnerInvtryInv = false;
      this.chRef.detectChanges();
    })
  }

  //open modal for clickable counts
  OpenModalModalForFilterCount(content: any, flag: string) {
    this.DashbordsModel = this.modalService.open(content, {
      centered: true,
      size: 'xl',
      scrollable: true,
      backdrop: 'static'
    });
    this.ShowFilteredCountList(flag);
  }

  ShowFilteredCountList(Flag?: any) {
    this.InvoicList = [];
    this.CommonDataListforTable = [];
    var ToDate = new FormControl(formatDate(this.ToDate.value, 'yyyy-MM-dd', 'en-US'));
    var FromDate = new FormControl(formatDate(this.FromDate.value, 'yyyy-MM-dd', 'en-US'));
    if (this.InvDataList != null && this.InvDataList != undefined || this.DataordrreturnList !== null || this.StockTransferData !== null || this.ChequeData !== null
      || this.InventoryInwrdData !== null) {

      if (Flag === 'TodayInv') {
        this.ModalcountTitle = "List View - Today's Invoices" + ' (' + this.TodayInv + ')';
        this.CommonDataListforTable = this.InvDataList.filter(x => x.InvCreatedDate === this.TodayDateForFilter && x.IsStockTransfer === 0);
      }
      else if (Flag === 'TodayInvStockTrnsfr') {
        this.ModalcountTitle = "List View - Today's Invoices Stock Transfer " + ' (' + this.TodayInvstockTrnsfr + ')';
        this.CommonDataListforTable = this.InvDataList.filter(x => x.InvCreatedDate === this.TodayDateForFilter && x.IsStockTransfer === 1);
      }
      else if (Flag === 'TodaysBoxes') {
        this.ModalcountTitle = "List View - Today's Boxes " + ' (' + this.TodaysBoxes + ')';
        this.CommonDataListforTable = this.InvDataList.filter(x => x.PackedDate === this.TodayDateForFilter && x.IsStockTransfer === 0);
      }
      else if (Flag === 'TodayBoxStockTrnsfr') {
        this.ModalcountTitle = "List View - Today's Boxes Stock Transfer " + ' (' + this.TodayBox + ')';
        this.CommonDataListforTable = this.InvDataList.filter(x => x.PackedDate === this.TodayDateForFilter && x.IsStockTransfer === 1);
      }
      else if (Flag === 'PendingLRStockTrnfr') {
        this.ModalcountTitle = "List View - Pending LR Updation Stock Transfer" + '(' + this.PendingLRstockTrnsfr + ')';
        this.CommonDataListforTable = this.InvDataList.filter(x => (x.InvStatus === 7) && (x.LRDate !== null && x.LRDate !== '0001-01-01' && x.LRDate !== '' && x.LRDate !== '1900-01-01') && x.IsStockTransfer === 1);
      }
      else if (Flag === 'PendingLR') {
        this.ModalcountTitle = "List View - Pending LR Updation " + '(' + this.PendingLR + ')';
        this.CommonDataListforTable = this.InvDataList.filter(x => (x.InvStatus === 7) && (x.LRDate !== null && x.LRDate !== '0001-01-01' && x.LRDate !== '' && x.LRDate !== '1900-01-01') && x.IsStockTransfer === 0);
      }
      else if (Flag === 'DispatchN') {
        this.ModalcountTitle = "List View - Total Dispatch - N " + '(' + this.DispatchN + ')';
        this.CommonDataListforTable = this.InvDataList.filter(x => x.DispatchN === 1 && x.IsStockTransfer === 0);
      }
      else if (Flag === 'DispatchN1') {
        this.ModalcountTitle = "List View - Total Dispatch - N + 1" + '(' + this.DispatchN1 + ')';
        this.CommonDataListforTable = this.InvDataList.filter(x => x.DispatchN1 === 1 && x.IsStockTransfer === 0);
      }
      else if (Flag === 'DispatchN2') {
        this.ModalcountTitle = "List View - Total Dispatch - N + 2" + '(' + this.DispatchN2 + ')';
        this.CommonDataListforTable = this.InvDataList.filter(x => x.DispatchN2 === 1 && x.IsStockTransfer === 0);
      }
      else if (Flag === 'DispatchPending') {
        this.ModalcountTitle = "List View - Dispatch Pending " + '(' + this.DispatchPending + ')';
        this.CommonDataListforTable = this.InvDataList.filter(x => x.InvStatus < 7);
      }
      else if (Flag === 'PendingDispatchStockTrnsfr') {
        this.ModalcountTitle = "List View - Pending Lr Updation Stock Transfer" + '(' + this.PendingDispatch + ')';
        this.CommonDataListforTable = this.InvDataList.filter(x => x.InvStatus < 7 && x.IsStockTransfer === 1);
      }
      else if (Flag === 'SalesAmtToday') {
        this.ModalcountTitle = "List View - Dispatch Pending " + '(' + this.SalesAmtToday + ')';
        this.CommonDataListforTable = this.InvDataList.filter(x => x.InvCreatedDate === this.TodayDateForFilter && x.IsStockTransfer === 0);
      }
      else if (Flag === 'LocalMode') {
        this.ModalcountTitle = "List View - No of boxes dispatched - Local " + '(' + this.LocalMode + ')';
        this.CommonDataListforTable = this.InvDataList.filter(x => x.TransportModeId === 1 && x.IsStockTransfer === 0);
      }
      else if (Flag === 'OtherCity') {
        this.ModalcountTitle = "List View - No of boxes dispatched - Other City " + '(' + this.OtherCity + ')';
        this.CommonDataListforTable = this.InvDataList.filter(x => x.TransportModeId === 2 && x.IsStockTransfer === 0);
      }
      else if (Flag === 'ByHand') {
        this.ModalcountTitle = "List View - No of boxes dispatched - Other City " + '(' + this.ByHand + ')';
        this.CommonDataListforTable = this.InvDataList.filter(x => x.TransportModeId === 3 && x.IsStockTransfer === 0);
      }

      // else if (Flag === 'PendingSRS') {
      //   this.ModalcountTitle = "List View - Pending SRS " + '(' + this.PendingSRS + ')';
      //   this.CommonDataListforTable = this.DataordrreturnList.filter(x => x.SRSId === null && x.AddedOnFormat >= FromDate.value && x.AddedOnFormat <= ToDate.value);//
      // }
      else if (Flag === 'TotalClaims') {
        this.ModalcountTitle = "List View - Pending Claim - Total" + '(' + this.TotalClaims + ')';
        this.CommonDataListforTable = this.DataordrreturnList.filter(x => x.LREntryId !== "" || x.LREntryId !== null);//
      }
      else if (Flag === 'Warehouse') {
        this.ModalcountTitle = "List View - Pending Claim - Ware house " + '(' + this.Warehouse + ')';
        this.CommonDataListforTable = this.DataordrreturnList.filter(x => x.RecvdAtOP === false);
      }
      else if (Flag === 'Auditorchk') {
        this.ModalcountTitle = "List View - Pending Claim - Auditor check " + '(' + this.Auditorchk + ')';
        this.CommonDataListforTable = this.DataordrreturnList.filter(x => x.SRSId > 0 && x.IsVerified === null);
      }
      else if (Flag === 'SalebleCN1') {
        this.ModalcountTitle = "List View - Saleable Credit Note - 1 days " + '(' + this.SalebleCN1 + ')';
        this.CommonDataListforTable = this.DataordrreturnList.filter(x => x.Day1 === 1);
      }
      else if (Flag === 'SalebleCN2') {
        this.ModalcountTitle = "List View - Saleable Credit Note - 2 days " + '(' + this.SalebleCN2 + ')';
        this.CommonDataListforTable = this.DataordrreturnList.filter(x => x.day2 === 1);
      }
      else if (Flag === 'SettPeriod15') {
        this.ModalcountTitle = "List View - Settlement Period - 15 days " + '(' + this.SettPeriod15 + ')';
        this.CommonDataListforTable = this.DataordrreturnList.filter(x => x.D15 === 1);
      }
      else if (Flag === 'SettPeriodMore45') {
        this.ModalcountTitle = "List View - Settlement Period - Above 45 days " + '(' + this.SettPeriodMore45 + ')';
        this.CommonDataListforTable = this.DataordrreturnList.filter(x => x.D45 === 1);
      }
      else if (Flag === 'TodysCong') {
        this.ModalcountTitle = "List View - Settlement Period - Month Consignment  " + '(' + this.TodysCong + ')';
        this.CommonDataListforTable = this.DataordrreturnList.filter(x => x.ReceiptDate === this.TodayDateForFilter);
      }
      else if (Flag === 'MonthCong') {
        this.ModalcountTitle = "List View - Settlement Period - Month Consignment  " + '(' + this.MonthCong + ')';
        this.CommonDataListforTable = this.DataordrreturnList.filter(x => x.ReceiptDate >= FromDate.value && x.ReceiptDate <= ToDate.value);
      }
      else if (Flag === 'TotalChqBounced') {
        this.ModalcountTitle = "List View - Total Cheque Bounced  " + '(' + this.TotalChqBounced + ')';
        this.CommonDataListforTable = this.ChequeData.filter(x => x.ChqStatus === 5 && x.ReturnedDate >= FromDate.value && x.ReturnedDate <= ToDate.value);
      }
      else if (Flag === 'TotalFirstNotice') {
        this.ModalcountTitle = "List View - Total First Notice  " + '(' + this.TotalFirstNotice + ')';
        this.CommonDataListforTable = this.ChequeData.filter(x => x.ChqStatus === 6 && x.FirstNoticeDate >= FromDate.value && x.FirstNoticeDate <= ToDate.value);
      }
      else if (Flag === 'TotalLegalNotice') {
        this.ModalcountTitle = "List View - Total Legal Notice  " + '(' + this.TotalLegalNotice + ')';
        this.CommonDataListforTable = this.ChequeData.filter(x => x.ChqStatus === 7 && x.LegalNoticeDate >= FromDate.value && x.LegalNoticeDate <= ToDate.value);
      }
      else if (Flag === 'DepositedDay') {
        this.ModalcountTitle = "List View - Deposited Day  " + '(' + this.DepositedDay + ')';
        this.CommonDataListforTable = this.ChequeData.filter(x => x.ChqStatus === 4 && x.DepositedDate === this.TodayDateForFilter);
      }
      else if (Flag === 'DepositedMonth') {
        this.ModalcountTitle = "List View - Deposited Month  " + '(' + this.DepositedMonth + ')';
        this.CommonDataListforTable = this.ChequeData.filter(x => x.ChqStatus === 4 && x.DepositedDate >= FromDate.value && x.DepositedDate <= ToDate.value);
      }
      else if (Flag === 'Totalvehical') {
        this.ModalcountTitle = "List View - Total Vehical" + '(' + this.Totalvehical + ')';
        this.CommonDataListforTable = this.InventoryInwrdData.filter(x => (x.AddedOn !== "0001-01-01" || x.AddedOn !== "" || x.AddedOn !== null) && (x.AddedOn >= FromDate.value && x.AddedOn <= ToDate.value));
      }
      else if (Flag === 'Pendingclaim') {
        this.ModalcountTitle = " List View - Pending claim" + '(' + this.Pendingclaim + ')';
        this.CommonDataListforTable = this.InventoryInwrdData.filter(x => (x.ClaimNo !== "" && x.ClaimNo !== null) && (x.ClaimApproveBy === null));
      }
      else if (Flag === 'PendingSan') {
        this.ModalcountTitle = " List View - Pending San" + '(' + this.PendingSan + ')';
        this.CommonDataListforTable = this.InventoryInwrdData.filter(x => (x.SANNo !== "" && x.SANNo !== null) && (x.SANApproveBy === null));
      }

      // new instance for MatTableDataSource
      this.DataSource.data = [];
      this.DataSourceForLRSRSCNforDataOrdrRtrn.data = [];
      this.DataSourceInveontoryInward.data = [];
      this.DataSourceForInvPickListStockTrnsfer.data = [];
      this.DataSourceForLRSRSCNforDataOrdrRtrn = new MatTableDataSource(this.CommonDataListforTable);
      this.DataSourceInveontoryInward = new MatTableDataSource(this.CommonDataListforTable);
      this.DataSourceChequeData = new MatTableDataSource(this.CommonDataListforTable);
      this.DataSource = new MatTableDataSource(this.CommonDataListforTable);
      this.chRef.detectChanges();
    }
  }

}
