import { PaginatorDirective } from './paginator.directive';

describe('PaginatorDirective', () => {
  it('should create an instance', () => {
    const directive = new PaginatorDirective();
    expect(directive).toBeTruthy();
  });
});
