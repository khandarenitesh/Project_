
export class DashbordorderDispatchcountmodel {
  TodayInv: number = 0;
  TotalInvoices: number = 0;
  CummPL: number = 0;
  InvPerMonth: number = 0;
  TodaysBoxes: number = 0;
  CummBoxes: number = 0;
  PendingLR: number = 0;
  DispatchN: number = 0;
  DispatchN1: number = 0;
  DispatchN2: number = 0;
  DispatchPending: number = 0;
  SalesAmtToday: number = 0;
  SalesAmtCumm: number = 0;
  NotDispPckdInv: number = 0;
  NotDispPckdBox: number = 0;
  LocalMode: number = 0;
  OtherCity: number = 0;
  ByHand: number = 0;
}
export class InventoryCountModel {
    BranchId: number = 0;
    CompId: number = 0;
    Totalvehical: number = 0;
    Totalboxes: number = 0;
    Pendingclaim: number = 0;
    PendingSan: number = 0;
}
export class OrderReturnModel {
  TotalClaims: number = 0;
  Warehouse: number = 0;
  Auditorchk: number = 0;
  RecvdAtOPCnt: number = 0;
  SaleableClaim: number = 0;
  TodysCong: number = 0;
  MonthCong: number = 0;
  SalebleCN1: number = 0;
  SalebleCN2: number = 0;
  SalebleCN2_7: number = 0;
  SalebleCN7Plus: number = 0;
  PendingCN: number = 0;
  SettPeriod15: number = 0;
  SettPeriod30: number = 0;
  SettPeriod45: number = 0;
  SettPeriodMore45: number = 0;
}

export class ChequeAcctModel {
    TotalChqBounced: number = 0;
    TotalFirstNotice: number = 0;
    TotalLegalNotice: number = 0;
    DepositedDay: number = 0;
    DepositedMonth: number = 0;
    DealyDeposited: number = 0;
    Overduestk: number = 0;
    NTotalFirstNotice: number = 0;
    NTotalLegalNotice: number = 0;
}

export class StockTransferModel {
  TodayInvstockTrnsfr : number = 0;
    CummInvstockTrnsfr : number = 0;
    CummPL : number = 0;
    PendingDispatch : number = 0;
    TodayBox : number = 0;
    CummBox : number = 0;
    PendingLRstockTrnsfr : number = 0;
}



