import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-select-branch',
  templateUrl: './select-branch.component.html',
  styleUrls: ['./select-branch.component.scss']
})
export class SelectBranchComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
