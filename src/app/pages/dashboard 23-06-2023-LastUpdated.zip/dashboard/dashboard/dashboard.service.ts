import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { map } from 'rxjs/operators';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})

export class DashboardService {

  isLoadingSubject: BehaviorSubject<boolean>;

  constructor(private _httpClient: HttpClient) { }

  private GetBranchList_Url = `${environment.apiUrl}Masters/GetBranchList`;
  private GetCompanyBranchList_Url = `${environment.apiUrl}Masters/GetCompanyBranchRelationList`;
  private GetOrderdiscount_Url = `${environment.apiUrl}OrderDispatch/AllOrderDispatchCount`;
  private GetInvenInwardcount_Url = `${environment.apiUrl}InventoryInward/InventoryCountForallLogin`;
  private GetOrderReturnDashCount_Url = `${environment.apiUrl}OrderReturn/GetDashBordCount`;
  private GetChequeAccountingCount_Url = `${environment.apiUrl}ChequeAccounting/GetDashbordCnt`;
  private StockTranscountdashbord_Url = `${environment.apiUrl}StockTransfer/GetStockTransferDashbordCount`;
  private GetOrderReturnCountNew_Url = `${environment.apiUrl}OrderReturn/GetDashBordCount`;

  // Get Branch List
  getBranchList_Service(Status: string): Observable<any> {
    return this._httpClient.get(this.GetBranchList_Url + '/' + Status, { observe: 'response' })
      .pipe(map(result => {
        // login successful if there's a jwt token in the response
        if (result) {
        }
        return result.body;
      }));
  }

  // Company Branch Relation List
  getCompanyBranch_Serive(CompanyId: number): Observable<any> {
    return this._httpClient.get(this.GetCompanyBranchList_Url + '/' + CompanyId, { observe: 'response' })
      .pipe(map(result => {
        if (result) {
        }
        return result.body;
      }));
  }

  //Get Order dispatch count for supervisor
  GetOrderDisCount(DataModelCounts: any): Observable<any> {
    return this._httpClient.post(this.GetOrderdiscount_Url, DataModelCounts, { observe: 'response' }).pipe(
      map(result => {
        if (result) {

        }
        return result.body;
      }),
    );
  }

  //Get Inventory Inward count for supervisor
  GetInvenInwardCount(DataModelCount: any): Observable<any> {
    return this._httpClient.post(this.GetInvenInwardcount_Url, DataModelCount, { observe: 'response' }).pipe(
      map(result => {
        if (result) {

        }
        return result.body;
      }),
    );
  }

  //Get Order Return Count for Supervisor
  GetOrderreturnDashbord(DataModelCount: any): Observable<any> {
    return this._httpClient.post(this.GetOrderReturnDashCount_Url, DataModelCount, { observe: 'response' }).pipe(
      map(result => {
        if (result) {

        }
        return result.body;
      }),
    );
  }

  //Get Order Return Count New
  GetOrderReturnNewDashbord(DataModelCount:any) : Observable<any> {
    return this._httpClient.post(this.GetOrderReturnCountNew_Url,DataModelCount, {observe: 'response'}).pipe (
      map(result => {
        if(result) {

        }
        return result.body;
      }),
    );
  }

  //Get Cheque Accounting Count for Operator
  GetChequeAccountingDashbord(DataModelCount: any): Observable<any> {
    return this._httpClient.post(this.GetChequeAccountingCount_Url, DataModelCount, { observe: 'response' }).pipe(
      map(result => {
        if (result) {

        }
        return result.body;
      })
    )
  }

  //Get Stock Transfer count for Operaator
  GetstocktransferCountdashbord(DataModelCount: any): Observable<any> {
    return this._httpClient.post(this.StockTranscountdashbord_Url, DataModelCount, { observe: 'response' }).pipe(
      map(result => {
        if (result) {

        }
        return result.body;
      })
    )
  }





}
