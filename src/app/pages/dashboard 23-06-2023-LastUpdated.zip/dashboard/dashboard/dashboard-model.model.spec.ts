import { DashboardModel } from './dashboard-model.model';

describe('DashboardModel', () => {
  it('should create an instance', () => {
    expect(new DashboardModel()).toBeTruthy();
  });
});
