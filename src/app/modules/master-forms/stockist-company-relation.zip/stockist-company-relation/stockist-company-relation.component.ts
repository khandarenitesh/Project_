import { ChangeDetectorRef, Component, OnInit, ViewChild } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatOption } from '@angular/material/core';
import { MatSelect } from '@angular/material/select';
import { AppCode } from 'src/app/app.code';
import { MastersServiceService } from '../../master-forms/Services/masters-service.service';
import { ToastrService } from 'ngx-toastr';
import { StockistBranchModel } from '../Models/Stockist-Branch-Model';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { startWith, map } from 'rxjs/operators';

export class StockistCompanyModel {
  CompanyId: number = 0;
  CompanyName: string = "";
  CompanyCode: number = 0;
}

@Component({
  selector: 'app-stockist-company-relation',
  templateUrl: './stockist-company-relation.component.html',
  styleUrls: ['./stockist-company-relation.component.scss']
})
export class StockistCompanyRelationComponent implements OnInit {

  StockistCompany = ['SrNo', 'StockistName', 'StockistNo', 'CompName', 'CompanyCode'];
  @ViewChild('paginator') paginator: MatPaginator;
  @ViewChild('Sort') Sort: MatSort;
  public DataSource = new MatTableDataSource<any>();

  stockistbranchForm: FormGroup;
  stockistbranchModel: StockistBranchModel
  StockistList: any[] = [];
  CompanyList: any[] = [];
  UserId: number = 0;
  defaultform: any = {
    Stockist: '',
    Company: '',
  };
  InvId: number = 0;
  StockistId: number = 0;
  CompId: number = 0;
  pageState: string = "";
  btnCancelText: string = "";
  isLoading: boolean = false;
  BranchId: number = 0;
  CompanyId: number = 0;
  stockistcompanyList: any[] = [];
  BranchList: any[] = [];
  InvalidCompany : boolean = false;

  @ViewChild('select') select: MatSelect;
  allSelected = false;
  State: any = {
    state: ''
  };

  formControlCompanyName = new FormControl('');
  CompanyNameArray: Observable<StockistCompanyModel[]>;

  stockistbranch: string = "";
  selectedCompanyList: any[] = [];
  CompanyMasterObj = new FormControl();
  submitted: boolean = false;
  stockistcompnayList: any[] = [];
  searchModel: string = '';

  constructor(
    private fb: FormBuilder,
    private _service: MastersServiceService,
    private chRef: ChangeDetectorRef,
    private toaster: ToastrService,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.stockistbranch = "Add Stockist Company Relation";
    this.pageState = AppCode.saveString;
    this.btnCancelText = AppCode.cancelString;
    this.initForm();
    this.GetCompanyList();
    let obj = AppCode.getUser();
    this.BranchId = obj.BranchId;
    this.CompanyId = obj.CompanyId;
    this.UserId = obj.UserId;
    this.GetStockistCompanyList();
    this.chRef.detectChanges();
  }


  get f(): { [key: string]: AbstractControl } {
    return this.stockistbranchForm.controls;
  }

  initForm() {
    this.stockistbranchForm = this.fb.group({

      Stockist: [
        this.defaultform.Stockist,
        Validators.compose([
          Validators.required,
          Validators.maxLength(250),
        ]),
      ],
      Company: [
        this.defaultform.Company,
        Validators.compose([
          Validators.required,
          Validators.maxLength(250),
        ]),
      ],
    });
  }

  GetCompanyList() {
    this._service.getCompanyList_Service(AppCode.allString)
      .subscribe(
        (data: any) => {
          this.CompanyList = data;
          this.CompanyList = this.CompanyList.sort((a:any,b:any) =>a.CompanyName.localeCompare(b.CompanyName));
          this.CompanyNameArray = this.f.Company.valueChanges
            .pipe(
              startWith<string | StockistCompanyModel>(''),
              map(value => typeof value === 'string' ? value : value !== null ? value.CompanyName : null),
              map(CompanyName => CompanyName ? this.filterCompanyName(CompanyName) : this.CompanyList.slice())
            );
          this.chRef.detectChanges();
        },
        (error) => {
          console.error(error);
        }
      );
  }

  // Autocomplete Search Filter
  private filterCompanyName(name: string): StockistCompanyModel[] {
    this.InvalidCompany = false;
    const filterValue = name.toLowerCase();
    return this.CompanyList.filter((option: any) =>
      option.CompanyName.toLowerCase().includes(filterValue));
  }

  // Select or Choose dropdown values
  displayFnCompanyName(name: StockistCompanyModel): string {
    return name && name.CompanyName ? name.CompanyName : '';
  }
companyValidation(){
  this.submitted = false;
  if((this.f.Company.value.CompanyId === '' || this.f.Company.value.CompanyId === undefined || this.f.Company.value.CompanyId === null ))
    {
       this.InvalidCompany = true;
       return;
    }else{
      this.InvalidCompany = false;
    }
}
  // Save Stockist Company Relation
  SaveStockistCompany() {
    this.submitted = true;
    var arrStockist = [];
    if (!this.stockistbranchForm.valid) {
      this.isLoading = false;
      this.InvalidCompany = false;
      return;
    } else {
      this.stockistbranchModel = new StockistBranchModel();
      this.stockistbranchModel.CompId = this.f.Company.value.CompanyId;
      // multiple Stockist
      arrStockist.push(this.f.Stockist.value);
      arrStockist.forEach((element: any) => {
        for (var i = 0; i < element.length; i++) {
          this.stockistbranchModel.Stockieststr += element[i].StockistId + ",";
        }
      });

      if (this.pageState == AppCode.saveString) {
        this.stockistbranchModel.Action = AppCode.addString;
      }
      else {
        this.stockistbranchModel.Action = AppCode.editString;
      }
      this.stockistbranchModel.Addedby = String(this.UserId);

      this._service.StockistCompanyAdd_Service(this.stockistbranchModel)
        .subscribe((data: any) => {
          if (data === AppCode.SuccessStatus) {
            if (this.pageState == AppCode.saveString) {
              this.toaster.success(AppCode.msg_saveSuccess);
            } else {
              this.toaster.success(AppCode.msg_updateSuccess);
            }
            this.redirect();
            this.GetStockistCompanyList();
          } else if (data === AppCode.ExistsStatus) {
            this.toaster.warning(AppCode.msg_exist);
            this.isLoading = false;
            this.chRef.detectChanges();
          } else {
            this.toaster.error(data);
            this.redirect();
          }
        },
          (error: any) => {
            console.error(error);
          });
    }
  }

  //select option
  optionClick() {
    let newStatus = true;
    this.select.options.forEach((item: MatOption) => {
      if (!item.selected) {
        newStatus = false;
      }
    });
    this.allSelected = newStatus;
  }

  //get stockist company list
  GetStockistCompanyList() {
    this.isLoading = true;
    this._service.getStockistCompany_Service(this.StockistId).subscribe((data: any) => {
      if (data.length > 0 && data != null && data != [] && data != "" && data != undefined) {
        this.stockistcompanyList = data;
        this.DataSource.data = data;
        this.DataSource.paginator = this.paginator;
        this.DataSource.sort = this.Sort;
        this.isLoading = false;
        this.chRef.detectChanges();
      } else {
        this.DataSource.data = [];
        this.isLoading = false;
        this.chRef.detectChanges();
      }
    });
  }

  OnChangeCompany() {
    this.StockistList = [];  // stockistlist new instance
    this._service.getStockistListByCompany_Service(this.f.Company.value.CompanyId, AppCode.allString)
      .subscribe((data: any) => {
        this.StockistList = data;
        this.selectedCompanyList = []; // selected company list new instance
        this.selectedCompanyList = this.StockistList.filter(s => s.Checked === 1);
        this.f.Stockist.setValue(this.selectedCompanyList);
        this.chRef.detectChanges();
      },
        (error) => {
          console.error(error);
        })
  }

  applyFilter() {
    this.isLoading = true;
    this.searchModel = this.searchModel.toLowerCase(); // Datasource defaults to lowercase matches
    this.DataSource.filter = this.searchModel;
    this.isLoading = false;
    this.chRef.detectChanges(); // IMMEDIATE ACTION FIRED
  }

  redirect() {
    this.ClearForm();
    this.router.navigate(['/modules/masters/stockist-company-relation']);
    this.isLoading = false;
    this.chRef.detectChanges();
  }

  ClearForm() {
    this.f.Stockist.setValue('');
    this.f.Company.setValue('');
    this.formControlCompanyName.reset();
    this.isLoading = false;
    this.chRef.detectChanges();
  }

}
