import { formatDate } from '@angular/common';
import { HttpClient, HttpEventType, HttpHeaders, HttpResponse } from '@angular/common/http';
import { ChangeDetectorRef, Component, ElementRef, EventEmitter, OnInit, Output, ViewChild } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { WebcamImage, WebcamInitError } from 'ngx-webcam';
import { Observable, Subject, Subscription } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { AppCode } from 'src/app/app.code';
import { MastersServiceService } from 'src/app/modules/master-forms/Services/masters-service.service';
import { OrderReturnService } from 'src/app/modules/order-return/Services/order-return.service';
import { OcrIntegrationService } from '../../Services/ocr-integration.service';
import { OCRDataModel } from '../../Model/OCRDataModel';



@Component({
  selector: 'app-ocr-integration',
  templateUrl: './ocr-integration.component.html',
  styleUrls: ['./ocr-integration.component.scss']
})
export class OcrIntegrationComponent implements OnInit {

  @Output() getPicture = new EventEmitter<WebcamImage>();
  showWebcam = true;
  isCameraExist = true;
  UserId: Number = 0;
  BranchId: number = 0;
  CompanyId: number = 0;
  submitted: boolean = false;
  isLoading: boolean = false;
  OCRSaveDataForm: FormGroup;
  StockistNameList: any[] = [];
  errors: WebcamInitError[] = [];
  StockistNameArray: Observable<OCRDataModel[]>;
  StockistName: boolean = false;
  pageState: string = "";
  btnCancelText: string = "";
  OCRDataModel: OCRDataModel = new OCRDataModel();
  ManufacturingDate: string = "";
  ExpiryDate: string = "";
  MrpRs: string = "";
  BatchNo: string = "";
  selectedFiles?: FileList;
  currentFile?: File;
  progress = 0;
  message = '';
  preview = '';
  imageInfos?: Observable<any>;
  ManufaturingDateFormat: any;
  ExpiryDateFormat: any;
  ExpiryDateMonth: any;
  ExpiryDateYear: any;
  ManufacturingDateYear: any;
  ManufacturingDateMonth: any;
  CommonDateFormat: any;
  imageName: string = "";
  imgDt: Date = new Date();

  defaultform: any = {
    StockistName: '',
    MedicineTypes: '',
    LrClaimNo: '',
    BatchNo: '',
    Quantity: '',
    Unit: '',
    Code: '',
    ProductName: '',
    Returntype: '',
    Division: '',
    Plant: ''
  };

  public textOut!: string;
  ocrResult = '';
  OcrUploadedImage = '';
  webcamImage: WebcamImage | undefined;
  captureImage: string = "";
  BatchNoList: any[] = [];
  IsStockistDisable: boolean = false;

  @ViewChild('imageInput') imageInput: ElementRef<HTMLInputElement> | null = null;
  imageUrl: string | null = null;
  recognizedText: string | null = null;
  IamgeForOCRPath: any

  private trigger: Subject<any> = new Subject();
  private nextWebcam: Subject<any> = new Subject();

  constructor(private _service: MastersServiceService, private _appCode: AppCode,
    private _ToastrService: ToastrService, private fb: FormBuilder,
    private chef: ChangeDetectorRef, private ocrService: OrderReturnService, private httptest: HttpClient,
    private _ocrSerivce: OcrIntegrationService) { }


  ngOnInit(): void {
    this.pageState = AppCode.saveString;
    this.btnCancelText = AppCode.cancelString;
    this.initForm();
    let obj = AppCode.getUser();
    this.UserId = obj.UserId;
    this.BranchId = obj.BranchId;
    this.CompanyId = obj.CompanyId;
    this.GetStockistList();
  }

  get f(): { [key: string]: AbstractControl } {
    return this.OCRSaveDataForm.controls;
  }

  //form initilization
  initForm() {
    this.OCRSaveDataForm = this.fb.group({
      StockistName: [
        this.defaultform.StockistName,
        Validators.compose([
          Validators.required
        ]),
      ],
      LrClaimNo: [
        this.defaultform.LrClaimNo,
        Validators.compose([
          Validators.required
        ]),
      ],
      Quantity: [
        this.defaultform.Quantity,
        Validators.compose([
          Validators.required
        ]),
      ],
      Unit: [
        this.defaultform.Unit,
        Validators.compose([
          Validators.required
        ]),
      ],
      Code: [
        this.defaultform.Code,
        Validators.compose([
          Validators.required
        ]),
      ],
      ProductName: [
        this.defaultform.ProductName,
        Validators.compose([
          Validators.required
        ]),
      ],
      Returntype: [
        this.defaultform.Returntype,
        Validators.compose([
          Validators.required
        ]),
      ],
      Division: [
        this.defaultform.Division,
        Validators.compose([
          Validators.required
        ]),
      ],
      Plant: [
        this.defaultform.Plant,
        Validators.compose([
          Validators.required
        ]),
      ],
    });
  }

  // Get Stockist No. and Stockist Name
  GetStockistList() {
    debugger
    this._service.getStockistList_Service(this.BranchId, this.CompanyId, AppCode.IsActiveString)
      .subscribe(
        (data: any) => {
          this.StockistNameList = data;
          this.StockistNameList = this.StockistNameList.sort((a: any, b: any) => a.StockistName.localeCompare(b.StockistName));
          this.StockistNameArray = this.f.StockistName.valueChanges
            .pipe(
              startWith<string | OCRDataModel>(''),
              map(value => typeof value === 'string' ? value : value !== null ? value.StockistName : null),
              map(StockistName => StockistName ? this.filterStockistNo(StockistName) : this.StockistNameList.slice())
            );
          this.chef.detectChanges();
        },
        (error) => {
          console.error(error);
          this.chef.detectChanges();
        }
      );
  }

  // Autocomplete Search Filter
  private filterStockistNo(name: string): OCRDataModel[] {
    debugger
    this.StockistName = false;
    this.IsStockistDisable = true;
    this.f.StockistName.disable();
    const filterValue = name.toLowerCase();
    return this.StockistNameList.filter((option: any) =>
      option.StockistName.toLocaleLowerCase().includes(filterValue));

  }

  // Select or Choose dropdown values
  displayFnStockistName(StockstName: OCRDataModel): string {

    return StockstName && StockstName.StockistName ? StockstName.StockistName : '';
  }

  //Stockist drop down validtion
  stockistnameValidation() {
    this.submitted = false;
    this.IsStockistDisable = true;
    if ((this.f.StockistName.value.StockistName === "" || this.f.StockistName.value.StockistName === null || this.f.StockistName.value.StockistName === undefined)) {
      this.StockistName = true;
      this.IsStockistDisable = true;
      return;
    } else {
      this.StockistName = false;
      this.IsStockistDisable = false;
    }
  }

  //save OCR Data
  SaveOCRData() {
    debugger
    this.submitted = true;
    this.isLoading = true;
    if (!this.OCRSaveDataForm.valid) {
      this.isLoading = false;
      return;
    }
    this.OCRDataModel.BranchId = this.BranchId;
    this.OCRDataModel.CompId = this.CompanyId;
    this.OCRDataModel.StockistId = this.f.StockistName.value.StockistId;
    this.OCRDataModel.LR_ClaimNo = this.f.LrClaimNo.value;
    this.OCRDataModel.BatchNo = this.BatchNo;
    this.OCRDataModel.Quantity = this.f.Quantity.value;
    this.OCRDataModel.Unit = this.f.Unit.value;
    this.OCRDataModel.Code = this.f.Code.value;
    this.OCRDataModel.ProductName = this.f.ProductName.value;
    this.OCRDataModel.Returntype = this.f.Returntype.value.StockistId;
    this.OCRDataModel.Division = this.f.Division.value;
    this.OCRDataModel.Plant = this.f.Plant.value;
    this.OCRDataModel.EXP_Date = this.ExpiryDate;
    this.OCRDataModel.MFG_Date = this.ManufacturingDate;
    this.OCRDataModel.MRP_Price = this.MrpRs;
    this.OCRDataModel.Addedby = String(this.UserId);
    this.OCRDataModel.Action = "ADD";
    this._ocrSerivce.SaveOCRData_Service(this.OCRDataModel).subscribe(
      async (data: any) => {
        if (data > 0) {
          this._ToastrService.success(AppCode.msg_saveSuccess);
          this.ClearData();
          this.ClearImage();
          this.submitted = false;
          this.isLoading = false;
        }
        else if (data < 0) {
          this._ToastrService.warning('Batch no already exists!');
          this.chef.detectChanges();
        } else {
          this._ToastrService.error(AppCode.FailStatus);
        }
      },
      (error: any) => {
        console.log('Error:  ' + JSON.stringify(error));
        this.chef.detectChanges();
      }
    );
  }

  // Define regular expressions for each information extraction
  ConvertDataForSave(DetectedText: any) {
    debugger;
    //Batch No Regex Epression
    const batchNumberRegex1 = /B\.No\.([A-Z0-9]+)/;
    const batchNumberRegex2 = /Batch\.No\.:(.+)/;
    const batchNumberRegex3 = /BATCH NO\.:\s*([A-Z0-9]+)/;
    const batchNumberRegex4 = /B\.No\.:(.+)/;
    const batchNumberRegex5 = /Batch No\.([A-Z0-9]+)/;
    const batchNumberRegex6 = /Batch No:([A-Z0-9]+)/;
    const batchNumberRegex7 = /B\.NO:([A-Z0-9]+)/;
    const batchNumberRegex8 = /Batch\. No\. ([A-Z0-9]+)/;
    const batchNumberRegex9 = /B\.NO\.:(\w+)/;
    const batchNumberRegex10 = /B\.NO\.(\w+)/;
    const batchNumberRegex11 = /Batch No\.(\w+)/;
    const batchNumberRegex12 = /Batch\. No\. (\w+)/;
    const rebatchNumberRegex13 = /B\.NO\.([A-Z0-9]+)/;
    const rebatchNumberRegex14 = /BINO\.([A-Z0-9]+)/;
    const batchNumberRegex15 = /B.No.\ ([A-Z0-9]+)/;
    const batchNumberRegex16 = /B\.No\. (\d+)/;
    const batchNumberRegex17 = /B\.No (\w+)/;
    const batchNumberRegex18 = /B\.NO (\w+)/;
    const batchNumberRegex19 = /B\.No\.(\w+)/;


    //Manufacturing Date
    const manufacturingDateRegex1 = /MFD\.([A-Z]{3}\.\d{2})/;
    const manufacturingDateRegex2 = /MFG\.([A-Z]{3}\.\d{2})/;
    const manufacturingDateRegex3 = /MFG\.([A-Z]+\.\d{4})/;
    const manufacturingDateRegex4 = /([A-Z]+\.\d{4})/;
    // const manufacturingDateRegex5 = /(\d{2}\/\d{4})/;
    const manufacturingDateRegex6 = /MFD\.(\d{2}\.\d{2}\.\d{2})/;
    const manufacturingDateRegex7 = /Mfg\.Date:\s*(\d{2}\/\d{4})/;
    const manufacturingDateRegex8 = /Mfg\. Date ([A-Z]{3}\.\d{4})/;
    const manufacturingDateRegex9 = /Mfg\.Dt\.:(.+)/;
    const manufacturingDateRegex10 = /Mfg\.Date: ([A-Z]+\s\d{4})/;
    const manufacturingDateRegex11 = /MFD\.([A-Z]{3} \d{2})/;
    const manufacturingDateRegex12 = /Mfg\.Dt:([A-Z]{3}\.\d{4})/;
    const manufacturingDateRegex13 = /MFG\.([A-Z]{3}\.\d{4})/;
    const manufacturingDateRegex14 = /Mfg\.Dt:([A-Z]{3}\.\d{2})/;
    const manufacturingDateRegex15 = /Mfg.Date:([A-Z]{3}\.\d{4})/;
    const manufacturingDateRegex16 = /Mfg\.Date:([A-Z]{3}\.\d{4})/;
    const manufacturingDateRegex17 = /Mfg\.Date:([\d/]+)/;
    const manufacturingDateRegex18 = /Mfg\.Date: ([A-Z]{3}\.\d{4})/;
    const manufacturingDateRegex19 = /MFD\.:(\w{3}\.\d{2})/;
    const manufacturingDateRegex20 = /MFD\.([A-Z]{3}:\d{2})/;
    const manufacturingDateRegex21 = /WFD\.([A-Z]+:\d{2})/;
    const manufacturingDateRegex22 = /MFD\. ([A-Z]{3}\. \d{4})/;
    const manufacturingDateRegex23 = /MFG\.(\d{2}\/\d{4})/;
    const manufacturingDateRegex24 = /MFG\.(\d{2}\/\d{4})/;
    const manufacturingDateRegex25 = /MFD\. ([A-Z]{3}\.\d{4})/;



    //Expiry Date
    const expiryDateRegex1 = /EXP\.([A-Z]{3}\.\d{2})/;
    const expiryDateRegex2 = /Expiry Date: ([A-Z]+\.\d{2})/;
    const expiryDateRegex3 = /EXPIRY DATE ([A-Z]+\.\d{4})/;
    const expiryDateRegex4 = /([A-Z]+\.\d{4})/;
    const expiryDateRegex5 = /EXP\.([A-Z]{3}\.\d{4})/;
    // const expiryDateRegex6 = /(\d{2}\/\d{4})/;
    const expiryDateRegex7 = /Expiry Date:(.+)/;
    const expiryDateRegex8 = /EXP\.(\d{2}\.\d{2}\.\d{2})/;
    const expiryDateRegex9 = /(\d{2}\/\d{4}):(\d{2}\/\d{4})/;
    const expiryDateRegex10 = /EXP\.Dt\.:(.+)/;
    const expiryDateRegex11 = /Expiry Date: ([A-Z]+\.\d{4})/;
    const expiryDateRegex12 = /EXP\. ([A-Z]{3}\.\d{2}\.\d{2})/;
    const expiryDateRegex13 = /Expiry Date:([A-Z]{3}\.\d{4})/;
    const expiryDateRegex14 = /EXPIRY DATE\.([A-Z]{3}\.\d{4})/;
    const expiryDateRegex15 = /Expiry Date:([A-Z]{3}\.\d{2})/;
    const expiryDateRegex16 = /Use Before: ([A-Z]{3}\.\d{4})/;
    const expiryDateRegex17 = /EXPIRY DATE: ([A-Z]{3}\.\d{4})/;
    const expiryDateRegex18 = /Expiry Date:([\d/]+)/;
    const expiryDateRegex19 = /EXP\.:(\w{3}\.\d{2})/;
    const expiryDateRegex20 = /EXPI?([A-Z]{3}\.\d{2})/;
    const expiryDateRegex21 = /EXPIDEC\.(\d{2})/;
    const expiryDateRegex22 = /EXP\. ([A-Z]{3} \d{4})/;
    const expiryDateRegex23 = /EXP\.(\d{2}\/\d{4})/;
    const expiryDateRegex24 = /EXP\.(\w)/;
    const expiryDateRegex25 = /EXP\. ([A-Z]{3}\. \d{4})/;



    //MRP
    const mrpValueRegex1 = /M\.R\.P\.RS\.([\d.]+)/;
    const mrpValueRegex2 = /M\.R\.P\.RS:\s*([\d.]+)/;
    const mrpValueRegex3 = /M\.R\.P\. DOLLAR SIGN ([\d.]+)/;
    const mrpValueRegex4 = /M\.R\.P\.RS: ([\d.]+)/;
    const mrpValueRegex5 = /M.R.P.RS: ([\d.]+)/;
    const mrpValueRegex6 = /MRP\.RS\.([\d.]+)/;
    const mrpValueRegex7 = /M\.R\.P\. DOLLAR SIGN\. ([\d.]+)/;
    const mrpValueRegex8 = /RS\.([\d.]+)/;
    const mrpValueRegex9 = /M\.R\.P\.PER STRIP OF TABS\.RS\.([\d.]+)/;
    const mrpValueRegex10 = /M\.R\.P\.PER STRIP OF TABS\. RS\.([\d.]+)/;
    const mgfDateRegex11 = /Mfg\.Date:(.+)/;
    const mrpValueRegex12 = /M\.R\.P\.RS.:([\d.]+)/;
    const mgfLicNoRegex13 = /Mfg\.Lic\.No\.:(.+)/;
    const mgfLicNoRegex14 = /MFD\.([A-Z]{3}:\d{2})/;
    const mgfLicNoRegex15 = /M\.R\. > ([\d,]+)/;
    const mrpValueRegex16 = /M\.R\.P\.(\d+\.\d+)/;
    const mrpValueRegex17 = /M\.R\..Rs\.([\d.]+)/;
    const mrpValueRegex18 = /M\.R\.P\.Rs\.([\d.]+)/;
    const mrpValueRegex19 = /M\.R\.P\.([\d.]+)/;


    //batch No. Start
    if (!this.BatchNo) {

      if (!this.BatchNo) {
        this.BatchNo = this.extractInformation(DetectedText, batchNumberRegex1);
      }
      if (!this.BatchNo) {
        this.BatchNo = this.extractInformation(DetectedText, batchNumberRegex2);
      }
      if (!this.BatchNo) {
        this.BatchNo = this.extractInformation(DetectedText, batchNumberRegex3);
      }
      if (!this.BatchNo) {
        this.BatchNo = this.extractInformation(DetectedText, batchNumberRegex4);
      }
      if (!this.BatchNo) {
        this.BatchNo = this.extractInformation(DetectedText, batchNumberRegex5);
      }
      if (!this.BatchNo) {
        this.BatchNo = this.extractInformation(DetectedText, batchNumberRegex6);
      }
      if (!this.BatchNo) {
        this.BatchNo = this.extractInformation(DetectedText, batchNumberRegex7);
      }
      if (!this.BatchNo) {
        this.BatchNo = this.extractInformation(DetectedText, batchNumberRegex8);
      }
      if (!this.BatchNo) {
        this.BatchNo = this.extractInformation(DetectedText, batchNumberRegex9);
      }
      if (!this.BatchNo) {
        this.BatchNo = this.extractInformation(DetectedText, batchNumberRegex10);
      }
      if (!this.BatchNo) {
        this.BatchNo = this.extractInformation(DetectedText, batchNumberRegex11);
      }
      if (!this.BatchNo) {
        this.BatchNo = this.extractInformation(DetectedText, batchNumberRegex12);
      }
      if (!this.BatchNo) {
        this.BatchNo = this.extractInformation(DetectedText, rebatchNumberRegex13);
      }
      if (!this.BatchNo) {
        this.BatchNo = this.extractInformation(DetectedText, rebatchNumberRegex14);
      }
      if (!this.BatchNo) {
        this.BatchNo = this.extractInformation(DetectedText, batchNumberRegex15);
      }
      if (!this.BatchNo) {
        this.BatchNo = this.extractInformation(DetectedText, batchNumberRegex16);
      }
      if (!this.BatchNo) {
        this.BatchNo = this.extractInformation(DetectedText, batchNumberRegex17);
      }
      if (!this.BatchNo) {
        this.BatchNo = this.extractInformation(DetectedText, batchNumberRegex18);
      }
      if (!this.BatchNo) {
        this.BatchNo = this.extractInformation(DetectedText, batchNumberRegex19);
      }

    }

    //Manufacturing Date Start
    if (!this.ManufacturingDate) {
      if (!this.ManufacturingDate) {
        this.ManufacturingDate = this.extractInformation(DetectedText, manufacturingDateRegex1);
      }
      if (!this.ManufacturingDate) {
        this.ManufacturingDate = this.extractInformation(DetectedText, manufacturingDateRegex2);
      }
      if (!this.ManufacturingDate) {
        this.ManufacturingDate = this.extractInformation(DetectedText, manufacturingDateRegex3);
      }
      if (!this.ManufacturingDate) {
        this.ManufacturingDate = this.extractInformation(DetectedText, manufacturingDateRegex4);
      }
      if (!this.ManufacturingDate) {
        // this.ManufacturingDate = this.extractInformation(DetectedText, manufacturingDateRegex5);
      }
      if (!this.ManufacturingDate) {
        this.ManufacturingDate = this.extractInformation(DetectedText, manufacturingDateRegex6);
      }
      if (!this.ManufacturingDate) {
        this.ManufacturingDate = this.extractInformation(DetectedText, manufacturingDateRegex7);
      }
      if (!this.ManufacturingDate) {
        this.ManufacturingDate = this.extractInformation(DetectedText, manufacturingDateRegex8);
      }
      if (!this.ManufacturingDate) {
        this.ManufacturingDate = this.extractInformation(DetectedText, manufacturingDateRegex9);
      }
      if (!this.ManufacturingDate) {
        this.ManufacturingDate = this.extractInformation(DetectedText, manufacturingDateRegex10);
      }
      if (!this.ManufacturingDate) {
        this.ManufacturingDate = this.extractInformation(DetectedText, manufacturingDateRegex11);
      }
      if (!this.ManufacturingDate) {
        this.ManufacturingDate = this.extractInformation(DetectedText, manufacturingDateRegex12);
      }
      if (!this.ManufacturingDate) {
        this.ManufacturingDate = this.extractInformation(DetectedText, manufacturingDateRegex13);
      }
      if (!this.ManufacturingDate) {
        this.ManufacturingDate = this.extractInformation(DetectedText, manufacturingDateRegex14);
      }
      if (!this.ManufacturingDate) {
        this.ManufacturingDate = this.extractInformation(DetectedText, manufacturingDateRegex15);
      }
      if (!this.ManufacturingDate) {
        this.ManufacturingDate = this.extractInformation(DetectedText, manufacturingDateRegex16);
      }
      if (!this.ManufacturingDate) {
        this.ManufacturingDate = this.extractInformation(DetectedText, manufacturingDateRegex17);
      }
      if (!this.ManufacturingDate) {
        this.ManufacturingDate = this.extractInformation(DetectedText, manufacturingDateRegex18);
      }
      if (!this.ManufacturingDate) {
        this.ManufacturingDate = this.extractInformation(DetectedText, manufacturingDateRegex19);
      }
      if (!this.ManufacturingDate) {
        this.ManufacturingDate = this.extractInformation(DetectedText, manufacturingDateRegex20);
      }
      if (!this.ManufacturingDate) {
        this.ManufacturingDate = this.extractInformation(DetectedText, manufacturingDateRegex21);
      }
      if (!this.ManufacturingDate) {
        this.ManufacturingDate = this.extractInformation(DetectedText, manufacturingDateRegex22);
      }
      if (!this.ManufacturingDate) {
        this.ManufacturingDate = this.extractInformation(DetectedText, manufacturingDateRegex23);
      }
      if (!this.ManufacturingDate) {
        this.ManufacturingDate = this.extractInformation(DetectedText, manufacturingDateRegex24);
      }
      if (!this.ManufacturingDate) {
        this.ManufacturingDate = this.extractInformation(DetectedText, manufacturingDateRegex25);
      }
    }
    //Expiry Date Start
    if (!this.ExpiryDate) {
      if (!this.ExpiryDate) {
        this.ExpiryDate = this.extractInformation(DetectedText, expiryDateRegex1);
      }
      if (!this.ExpiryDate) {
        this.ExpiryDate = this.extractInformation(DetectedText, expiryDateRegex2);
      }
      if (!this.ExpiryDate) {
        this.ExpiryDate = this.extractInformation(DetectedText, expiryDateRegex3);
      }
      if (!this.ExpiryDate) {
        this.ExpiryDate = this.extractInformation(DetectedText, expiryDateRegex4);
      }
      if (!this.ExpiryDate) {
        this.ExpiryDate = this.extractInformation(DetectedText, expiryDateRegex5);
      }
      if (!this.ExpiryDate) {
        // this.ExpiryDate = this.extractInformation(DetectedText, expiryDateRegex6);
      }
      if (!this.ExpiryDate) {
        this.ExpiryDate = this.extractInformation(DetectedText, expiryDateRegex7);
      }
      if (!this.ExpiryDate) {
        this.ExpiryDate = this.extractInformation(DetectedText, expiryDateRegex8);
      }
      if (!this.ExpiryDate) {
        this.ExpiryDate = this.extractInformation(DetectedText, expiryDateRegex9);
      }
      if (!this.ExpiryDate) {
        this.ExpiryDate = this.extractInformation(DetectedText, expiryDateRegex10);
      }
      if (!this.ExpiryDate) {
        this.ExpiryDate = this.extractInformation(DetectedText, expiryDateRegex11);
      }
      if (!this.ExpiryDate) {
        this.ExpiryDate = this.extractInformation(DetectedText, expiryDateRegex12);
      }
      if (!this.ExpiryDate) {
        this.ExpiryDate = this.extractInformation(DetectedText, expiryDateRegex13);
      }
      if (!this.ExpiryDate) {
        this.ExpiryDate = this.extractInformation(DetectedText, expiryDateRegex14);
      }
      if (!this.ExpiryDate) {
        this.ExpiryDate = this.extractInformation(DetectedText, expiryDateRegex15);
      }
      if (!this.ExpiryDate) {
        this.ExpiryDate = this.extractInformation(DetectedText, expiryDateRegex16);
      }
      if (!this.ExpiryDate) {
        this.ExpiryDate = this.extractInformation(DetectedText, expiryDateRegex17);
      }
      if (!this.ExpiryDate) {
        this.ExpiryDate = this.extractInformation(DetectedText, expiryDateRegex18);
      }
      if (!this.ExpiryDate) {
        this.ExpiryDate = this.extractInformation(DetectedText, expiryDateRegex19);
      }
      if (!this.ExpiryDate) {
        this.ExpiryDate = this.extractInformation(DetectedText, expiryDateRegex20);
      }
      if (!this.ExpiryDate) {
        this.ExpiryDate = this.extractInformation(DetectedText, expiryDateRegex21);
      }
      if (!this.ExpiryDate) {
        this.ExpiryDate = this.extractInformation(DetectedText, expiryDateRegex22);
      }
      if (!this.ExpiryDate) {
        this.ExpiryDate = this.extractInformation(DetectedText, expiryDateRegex23);
      }
      if (!this.ExpiryDate) {
        this.ExpiryDate = this.extractInformation(DetectedText, expiryDateRegex24);
      }
      if (!this.ExpiryDate) {
        this.ExpiryDate = this.extractInformation(DetectedText, expiryDateRegex25);
      }
    }
    //MRP Start
    if (!this.MrpRs) {
      if (!this.MrpRs) {
        this.MrpRs = this.extractInformation(DetectedText, mrpValueRegex1);
      }
      if (!this.MrpRs) {
        this.MrpRs = this.extractInformation(DetectedText, mrpValueRegex2);
      }
      if (!this.MrpRs) {
        this.MrpRs = this.extractInformation(DetectedText, mrpValueRegex3);
      }
      if (!this.MrpRs) {
        this.MrpRs = this.extractInformation(DetectedText, mrpValueRegex4);
      }
      if (!this.MrpRs) {
        this.MrpRs = this.extractInformation(DetectedText, mrpValueRegex5);
      }
      if (!this.MrpRs) {
        this.MrpRs = this.extractInformation(DetectedText, mrpValueRegex6);
      }
      if (!this.MrpRs) {
        this.MrpRs = this.extractInformation(DetectedText, mrpValueRegex7);
      }
      if (!this.MrpRs) {
        this.MrpRs = this.extractInformation(DetectedText, mrpValueRegex8);
      }
      if (!this.MrpRs) {
        this.MrpRs = this.extractInformation(DetectedText, mrpValueRegex9);
      }
      if (!this.MrpRs) {
        this.MrpRs = this.extractInformation(DetectedText, mrpValueRegex10);
      }
      if (!this.MrpRs) {
        this.MrpRs = this.extractInformation(DetectedText, mgfDateRegex11);
      }
      if (!this.MrpRs) {
        this.MrpRs = this.extractInformation(DetectedText, mrpValueRegex12);
      }
      if (!this.MrpRs) {
        this.MrpRs = this.extractInformation(DetectedText, mgfLicNoRegex13);
      }
      if (!this.MrpRs) {
        this.MrpRs = this.extractInformation(DetectedText, mgfLicNoRegex14);
      }
      if (!this.MrpRs) {
        this.MrpRs = this.extractInformation(DetectedText, mgfLicNoRegex15);
      }
      if (!this.MrpRs) {
        this.MrpRs = this.extractInformation(DetectedText, mrpValueRegex16);
      }
      if (!this.MrpRs) {
        this.MrpRs = this.extractInformation(DetectedText, mrpValueRegex17);
      }
      if (!this.MrpRs) {
        this.MrpRs = this.extractInformation(DetectedText, mrpValueRegex18);
      }
      if (!this.MrpRs) {
        this.MrpRs = this.extractInformation(DetectedText, mrpValueRegex19);
      }

    }

    //printed here after getting values.
    console.log('Batch Number:', this.BatchNo);
    console.log('Manufacturing Date:', this.ManufacturingDate);
    console.log('Expiry Date:', this.ExpiryDate);
    console.log('M.R.P. Value:', this.MrpRs);
    this.ValidDateFormat(this.ManufacturingDate, this.ExpiryDate);
    if (this.BatchNo !== null && this.BatchNo !== undefined && this.BatchNo !== "") {
      this.onChangeBatchNo();
    }
    this.chef.detectChanges();
  }

  ValidDateFormat(ManufacturingDate: any, ExpiryDate: any) {
    debugger;
    this.ManufacturingDateMonth = "";
    this.ExpiryDateMonth = "";
    this.ExpiryDateYear = "";
    if (ManufacturingDate !== null && ExpiryDate !== null) {
      if ((ManufacturingDate.length <= 6 && ExpiryDate.length <= 6)) {
        this.ManufacturingDateSubstring(ManufacturingDate);
        this.ExpiryDateDevideSubstring(ExpiryDate);
      }
      if (ManufacturingDate.length >= 6 && ExpiryDate.length >= 6) {
        this.ManufacturingDateSubstringGrtrsix(ManufacturingDate);
        this.ExpiryDateDevideSubstringGrtrsix(ExpiryDate);
      }
      if (ManufacturingDate.length <= 6) {
        this.ManufacturingDateSubstring(ManufacturingDate);
      }
      if (ExpiryDate.length <= 6) {
        this.ExpiryDateDevideSubstring(ExpiryDate);
      }
      if (this.ManufacturingDateYear.length === 2 || this.ExpiryDateYear.length === 2) {
        this.ManufacturingDateYear = "20" + this.ManufacturingDateYear;
        this.ExpiryDateYear = "20" + this.ExpiryDateYear;
        this.ConvertorConcateData();
      }
      this.ConvertorConcateData();
      console.log("Formatted Date ManufacturingDate -> ", this.ManufacturingDate);
      console.log("Formatted Date ExpiryDate -> ", this.ExpiryDate);
    }
    this.chef.detectChanges();
  }

  ExpiryDateDevideSubstring(ExpiryDate: any) {
    this.ExpiryDateMonth = ExpiryDate.substring(3, 0);
    this.ExpiryDateYear = ExpiryDate.substring(4, 10);
  }

  ManufacturingDateSubstring(ManufacturingDate: any) {
    this.ManufacturingDateMonth = ManufacturingDate.substring(3, 0);
    this.ManufacturingDateYear = ManufacturingDate.substring(4, 10);
  }

  ManufacturingDateSubstringGrtrsix(ManufacturingDate: any) {
    this.ManufacturingDateMonth = ManufacturingDate.substring(0, 2);
    this.ManufacturingDateYear = ManufacturingDate.substring(3, 10);
  }
  ExpiryDateDevideSubstringGrtrsix(ExpiryDate: any) {
    this.ExpiryDateMonth = ExpiryDate.substring(0, 2);
    this.ExpiryDateYear = ExpiryDate.substring(3, 10);
  }

  ConvertorConcateData() {
    this.ManufaturingDateFormat = String("01" + "-" + this.ManufacturingDateMonth + "-" + this.ManufacturingDateYear);
    this.ManufacturingDate = this.DateFormatForDDMMYYYY(this.ManufaturingDateFormat);
    this.ExpiryDateFormat = String("01" + "-" + this.ExpiryDateMonth + "-" + this.ExpiryDateYear);
    this.ExpiryDate = this.DateFormatForDDMMYYYY(this.ExpiryDateFormat);
  }

  //return date format
  DateFormatForDDMMYYYY(CommonDateFormat: any) {
    return formatDate(CommonDateFormat, 'dd-MM-yyyy', 'en-US')
  }

  // Match key and Return value
  extractInformation(str: any, regex: any) {
    const match = str.match(regex);
    return match ? match[1] : null
  }

  ClearData() {
    this.BatchNo = "";
    this.ExpiryDate = "";
    this.ManufacturingDate = "";
    this.OCRSaveDataForm.reset();
    this.chef.detectChanges();
  }

  ClearImage() {
    this.webcamImage = undefined;
    this.chef.detectChanges();
  }

  public getSnapshot(): void {
    this.trigger.next(void 0);
  }

  //captured images.
  public async captureImg(webcamImage: WebcamImage) {
    let formData = new FormData();
    this.webcamImage = webcamImage;
    this.captureImage = webcamImage!.imageAsDataUrl;
    this.imageName = "capture_" + this.imgDt.getDate() + "_" + this.imgDt.getSeconds() + ".png";
    var file = await this.urltoFile(this.captureImage, this.imageName, 'image/png');
    formData.append('upload', file);
    this._ocrSerivce.GetOCRImageTextData(formData)
      .subscribe((data: any) => {
        this.ConvertDataForSave(data.DetectedText)
      });
  }

  public get invokeObservable(): Observable<any> {
    return this.trigger.asObservable();
  }

  public get nextWebcamObservable(): Observable<any> {
    return this.nextWebcam.asObservable();
  }

  //return a promise that resolves with a File instance
  urltoFile(url: string, filename: string, mimeType: string) {
    return (fetch(url)
      .then(function (res) { return res.arrayBuffer(); })
      .then(function (buf) { return new File([buf], filename, { type: mimeType }); })
    );
  }

  //return mime Type of bs64
  base64MimeType(encoded: string) {
    var result = null;
    if (typeof encoded !== 'string') {
      return result;
    }
    var mime = encoded.match(/data:([a-zA-Z0-9]+\/[a-zA-Z0-9-.+]+).*,.*/);
    if (mime && mime.length) {
      result = mime[1];
    }
    return result;
  }

  // Bind on
  onChangeBatchNo() {
    debugger
    this.isLoading = true;
    this._ocrSerivce.GetProductDetailsByBatchNo_Service(this.BatchNo)
      .subscribe(
        (data: any) => {
          debugger
          if (this.BatchNo !== null) {
            this.f.Code.setValue(data.Code);
            this.f.ProductName.setValue(data.ProductName);
            this.isLoading = false;
            this.chef.detectChanges();
          }
        },
        (error) => {
          console.error(error);
          this.isLoading = false;
          this.chef.detectChanges();
        });
  }


}
