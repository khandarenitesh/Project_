import { formatDate } from '@angular/common';
import { HttpClient, HttpEventType, HttpHeaders, HttpResponse } from '@angular/common/http';
import { ChangeDetectorRef, Component, ElementRef, EventEmitter, OnInit, Output, ViewChild } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { WebcamImage, WebcamInitError } from 'ngx-webcam';
import { Observable, Subscription } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { AppCode } from 'src/app/app.code';
import { MastersServiceService } from 'src/app/modules/master-forms/Services/masters-service.service';
import { OrderReturnService } from 'src/app/modules/order-return/Services/order-return.service';
import { createWorker } from 'tesseract.js';
// import { ImageAnnotatorClient } from "@google-cloud/vision";

export class StokistModel {
  BranchId: number = 0;
  CompanyId: number = 0;
  StockistId: number = 0;
  StockistNo: string = "";
  StockistName: string = "";
  MedicineTypes: string = "";
  BatchNo: string = "";
  Addedby: string = "";
  ManufacturingDate: string = "";
  MrpRs: string = "";
  ExpiryDate: string = "";
  Action: string = "";
}

@Component({
  selector: 'app-ocr-integration',
  templateUrl: './ocr-integration.component.html',
  styleUrls: ['./ocr-integration.component.scss']
})
export class OcrIntegrationComponent implements OnInit {
  [x: string]: any;

  @Output() getPicture = new EventEmitter<WebcamImage>();
  showWebcam = true;
  isCameraExist = true;
  UserId: Number = 0;
  BranchId: number = 0;
  CompanyId: number = 0;
  submitted: boolean = false;
  isLoading: boolean = false;
  OCRSaveDataForm: FormGroup;
  StockistNameList: any[] = [];
  errors: WebcamInitError[] = [];
  StockistNameArray: Observable<StokistModel[]>;
  StockistName: boolean = false;
  pageState: string = "";
  btnCancelText: string = "";
  StokistModel: StokistModel = new StokistModel();
  ManufacturingDate: string = "";
  ExpiryDate: string = "";
  MrpRs: string = "";
  BatchNo: string = "";
  selectedFiles?: FileList;
  currentFile?: File;
  progress = 0;
  message = '';
  preview = '';
  imageInfos?: Observable<any>;
  ManufaturingDateFormat: any;
  ExpiryDateFormat: any;
  ExpiryDateMonth: any;
  ExpiryDateYear: any;
  ManufacturingDateYear: any;
  ManufacturingDateMonth: any;
  CommonDateFormat: any;

  defaultform: any = {
    StockistName: '',
    MedicineTypes: '',
  };

  private listSubscribers!: Subscription[];
  public textOut!: string;
  ocrResult = '';
  OcrUploadedImage = '';
  webcamImage: WebcamImage | undefined;


  @ViewChild('imageInput') imageInput: ElementRef<HTMLInputElement> | null = null;
  imageUrl: string | null = null;
  recognizedText: string | null = null;
  IamgeForOCRPath: any


  constructor(private _service: MastersServiceService, private _appCode: AppCode,
    private _ToastrService: ToastrService, private fb: FormBuilder,
    private chef: ChangeDetectorRef, private ocrService: OrderReturnService, private httptest: HttpClient) { }


  ngOnInit(): void {
    this.pageState = AppCode.saveString;
    this.btnCancelText = AppCode.cancelString;
    this.initForm();
    let obj = AppCode.getUser();
    this.UserId = obj.UserId;
    this.BranchId = obj.BranchId;
    this.CompanyId = obj.CompanyId;
    this.GetStockistList();
    this.listObserver();
  }

  get f(): { [key: string]: AbstractControl } {
    return this.OCRSaveDataForm.controls;
  }

  //form initilization
  initForm() {
    this.OCRSaveDataForm = this.fb.group({
      StockistName: [
        this.defaultform.StockistName,
        Validators.compose([
          Validators.required,
          Validators.maxLength(200)
        ]),
      ],
      MedicineTypes: [
        this.defaultform.MedicineTypes,
        Validators.compose([
          Validators.required,
          Validators.maxLength(200)
        ]),
      ],
    });
  }

  // Get Stockist No. and Stockist Name
  GetStockistList() {
    this._service.getStockistList_Service(this.BranchId, this.CompanyId, AppCode.IsActiveString)
      .subscribe(
        (data: any) => {
          this.StockistNameList = data;
          this.StockistNameList = this.StockistNameList.sort((a: any, b: any) => a.StockistName.localeCompare(b.StockistName));
          this.StockistNameArray = this.f.StockistName.valueChanges
            .pipe(
              startWith<string | StokistModel>(''),
              map(value => typeof value === 'string' ? value : value !== null ? value.StockistName : null),
              map(StockistName => StockistName ? this.filterStockistNo(StockistName) : this.StockistNameList.slice())
            );
          this.chef.detectChanges();
        },
        (error) => {
          console.error(error);
          this.chef.detectChanges();
        }
      );
  }

  // Autocomplete Search Filter
  private filterStockistNo(name: string): StokistModel[] {
    this.StockistName = false;
    const filterValue = name.toLowerCase();
    return this.StockistNameList.filter((option: any) =>
      option.StockistName.toLocaleLowerCase().includes(filterValue));
  }

  // Select or Choose dropdown values
  displayFnStockistName(StockstName: StokistModel): string {
    return StockstName && StockstName.StockistName ? StockstName.StockistName : '';
  }

  //Stockist drop down validtion
  stockistnameValidation() {
    this.submitted = false;
    if ((this.f.StockistName.value.StockistName === "" || this.f.StockistName.value.StockistName === null || this.f.StockistName.value.StockistName === undefined)) {
      this.StockistName = true;
      return;
    } else {
      this.StockistName = false;
    }
  }

  //save OCR Data
  SaveOCRData() {
    debugger
    this.submitted = true;
    this.isLoading = true;
    if (!this.OCRSaveDataForm.valid) {
      this.isLoading = false;
      return;
    }
    this.StokistModel.BranchId = this.BranchId;
    this.StokistModel.CompanyId = this.CompanyId;
    this.StokistModel.StockistName = this.f.StockistName.value.StockistId;
    this.StokistModel.MedicineTypes = this.f.MedicineTypes.value.StockistId;
    this.StokistModel.BatchNo = this.BatchNo;
    this.StokistModel.ExpiryDate = this.ExpiryDate;
    this.StokistModel.ManufacturingDate = this.ManufacturingDate;
    this.StokistModel.MrpRs = this.MrpRs;
    console.log('Form data received for submit -> ', this.StokistModel);
  }

  handleImage(webcamImage: WebcamImage) {
    this.webcamImage = webcamImage;
    this.doOCR(webcamImage.imageAsDataUrl);
    this.chef.detectChanges();
  }

  listObserver = () => {
    const observer1$ = this.ocrService.cbText
      .subscribe(({ text }) => {
        this.textOut = text;
      });
    this.listSubscribers = [observer1$];
    this.chef.detectChanges();
  };

  //Ocr from camera through captured images
  async doOCR(webcamImage: any) {
    console.log(webcamImage);
    const worker = createWorker({
      logger: (m: any) => console.log(m),
    });
    await worker.load();
    await worker.loadLanguage('eng');
    await worker.initialize('eng');
    const { data: { text } } = await worker.recognize(webcamImage);
    this.ocrResult = text;
    console.log(text);
    await worker.terminate();
    this.chef.detectChanges();
  }

  //select file for upload
  selectFile(event: any): void {
    debugger
    this.message = '';
    this.preview = '';
    this.progress = 0;
    this.selectedFiles = event.target.files;
    this.imgChangeEvt = event;
    if (this.selectedFiles) {
      const file: File | null = this.selectedFiles.item(0);
      // this.doOCRForUploadedFiles(file);
      this.recognizeText();
      this.showEditImage = true;
      if (file) {
        this.preview = '';
        this.currentFile = file;
        const reader = new FileReader();
        reader.onload = (e: any) => {
          console.log(e.target.result);
          this.preview = e.target.result;
        };
        reader.readAsDataURL(this.currentFile);
      }
    }
  }

  //Upload image for ocr
  upload(): void {
    debugger
    this.progress = 0;
    if (this.selectedFiles) {
      const file: File | null = this.selectedFiles.item(0);
      if (file) {
        this.currentFile = file;
        this.uploadService.upload(this.currentFile.name).subscribe({
          next: (event: any) => {
            if (event.type === HttpEventType.UploadProgress) {
              this.progress = Math.round((100 * event.loaded) / event.total);
            } else if (event instanceof HttpResponse) {
              this.message = event.body.message;
              this.imageInfos = this.uploadService.getFiles();
            }
          },
          error: (err: any) => {
            console.log(err);
            this.progress = 0;
            if (err.error && err.error.message) {
              this.message = err.error.message;
            } else {
              this.message = 'Could not upload the image!';
            }
            this.currentFile = undefined;
          },
        });
      }
      this.selectedFiles = undefined;
    }
  }

  // Getting Text Through OCR
  async doOCRForUploadedFiles(webcamImage: any) {
    debugger
    console.log(webcamImage);
    const worker = createWorker({
      logger: (m: any) => console.log(m),
    });

    try {
      await worker.load();
      await worker.loadLanguage('eng');
      await worker.initialize('eng');
      const { data: { text } } = await worker.recognize(webcamImage);
      this.OcrUploadedImage = text;
      this.ConvertDataForSave(this.OcrUploadedImage);
      console.log('text received from uploaded files ', text);
      this.chef.detectChanges();
    }
    catch (error) {
      console.log('error occured during ocr', error)
    }
    finally {
      await worker.terminate();
    }
    this.chef.detectChanges();
  }

  // Define regular expressions for each information extraction
  ConvertDataForSave(DataOcrUploadedImage: any) {
    //Batch No Regex Epression
    const batchNumberRegex1 = /B\.No\.([A-Z0-9]+)/;
    const batchNumberRegex2 = /Batch\.No\.:(.+)/;
    const batchNumberRegex3 = /BATCH NO\.:\s*([A-Z0-9]+)/;
    const batchNumberRegex4 = /B\.No\.:(.+)/;
    const batchNumberRegex5 = /Batch No\.([A-Z0-9]+)/;
    const batchNumberRegex6 = /Batch No:([A-Z0-9]+)/;
    const batchNumberRegex7 = /B\.NO:([A-Z0-9]+)/;
    const batchNumberRegex8 = /Batch\. No\. ([A-Z0-9]+)/;
    const batchNumberRegex9 = /B\.NO\.:(\w+)/;
    const batchNumberRegex10 = /B\.NO\.(\w+)/;
    const batchNumberRegex11 = /Batch No\.(\w+)/;
    const batchNumberRegex12 = /Batch\. No\. (\w+)/;
    const rebatchNumberRegex13 = /B\.NO\.([A-Z0-9]+)/;
    const rebatchNumberRegex14 = /BINO\.([A-Z0-9]+)/;

    //Manufacturing Date
    const manufacturingDateRegex1 = /MFD\.([A-Z]{3}\.\d{2})/;
    const manufacturingDateRegex2 = /MFG\.([A-Z]{3}\.\d{2})/;
    const manufacturingDateRegex3 = /MFG\.([A-Z]+\.\d{4})/;
    const manufacturingDateRegex4 = /([A-Z]+\.\d{4})/;
    const manufacturingDateRegex5 = /(\d{2}\/\d{4})/;
    const manufacturingDateRegex6 = /MFD\.(\d{2}\.\d{2}\.\d{2})/;
    const manufacturingDateRegex7 = /Mfg\.Date:\s*(\d{2}\/\d{4})/;
    const manufacturingDateRegex8 = /Mfg\. Date ([A-Z]{3}\.\d{4})/;
    const manufacturingDateRegex9 = /Mfg\.Dt\.:(.+)/;
    const manufacturingDateRegex10 = /Mfg\.Date: ([A-Z]+\s\d{4})/;
    const manufacturingDateRegex11 = /MFD\.([A-Z]{3} \d{2})/;
    const manufacturingDateRegex12 = /Mfg\.Dt:([A-Z]{3}\.\d{4})/;
    const manufacturingDateRegex13 = /MFG\.([A-Z]{3}\.\d{4})/;
    const manufacturingDateRegex14 = /Mfg\.Dt:([A-Z]{3}\.\d{2})/;
    const manufacturingDateRegex15 = /Mfg.Date:([A-Z]{3}\.\d{4})/;
    const manufacturingDateRegex16 = /Mfg\.Date:([A-Z]{3}\.\d{4})/;
    const manufacturingDateRegex17 = /Mfg\.Date:([\d/]+)/;
    const manufacturingDateRegex18 = /Mfg\.Date: ([A-Z]{3}\.\d{4})/;
    const manufacturingDateRegex19 = /MFD\.:(\w{3}\.\d{2})/;
    const manufacturingDateRegex20 = /MFD\.([A-Z]{3}:\d{2})/;
    const manufacturingDateRegex21 = /WFD\.([A-Z]+:\d{2})/;


    //Expiry Date
    const expiryDateRegex1 = /EXP\.([A-Z]{3}\.\d{2})/;
    const expiryDateRegex2 = /Expiry Date: ([A-Z]+\.\d{2})/;
    const expiryDateRegex3 = /EXPIRY DATE ([A-Z]+\.\d{4})/;
    const expiryDateRegex4 = /([A-Z]+\.\d{4})/;
    const expiryDateRegex5 = /EXP\.([A-Z]{3}\.\d{4})/;
    const expiryDateRegex6 = /(\d{2}\/\d{4})/;
    const expiryDateRegex7 = /Expiry Date:(.+)/;
    const expiryDateRegex8 = /EXP\.(\d{2}\.\d{2}\.\d{2})/;
    const expiryDateRegex9 = /(\d{2}\/\d{4}):(\d{2}\/\d{4})/;
    const expiryDateRegex10 = /EXP\.Dt\.:(.+)/;
    const expiryDateRegex11 = /Expiry Date: ([A-Z]+\.\d{4})/;
    const expiryDateRegex12 = /EXP\. ([A-Z]{3}\.\d{2}\.\d{2})/;
    const expiryDateRegex13 = /Expiry Date:([A-Z]{3}\.\d{4})/;
    const expiryDateRegex14 = /EXPIRY DATE\.([A-Z]{3}\.\d{4})/;
    const expiryDateRegex15 = /Expiry Date:([A-Z]{3}\.\d{2})/;
    const expiryDateRegex16 = /Use Before: ([A-Z]{3}\.\d{4})/;
    const expiryDateRegex17 = /EXPIRY DATE: ([A-Z]{3}\.\d{4})/;
    const expiryDateRegex18 = /Expiry Date:([\d/]+)/;
    const expiryDateRegex19 = /EXP\.:(\w{3}\.\d{2})/;
    const expiryDateRegex20 = /EXPI?([A-Z]{3}\.\d{2})/;
    const expiryDateRegex21 = /EXPIDEC\.(\d{2})/;

    //MRP
    const mrpValueRegex1 = /M\.R\.P\.RS\.([\d.]+)/;
    const mrpValueRegex2 = /M\.R\.P\.RS:\s*([\d.]+)/;
    const mrpValueRegex3 = /M\.R\.P\. DOLLAR SIGN ([\d.]+)/;
    const mrpValueRegex4 = /M\.R\.P\.RS: ([\d.]+)/;
    const mrpValueRegex5 = /M.R.P.RS: ([\d.]+)/;
    const mrpValueRegex6 = /MRP\.RS\.([\d.]+)/;
    const mrpValueRegex7 = /M\.R\.P\. DOLLAR SIGN\. ([\d.]+)/;
    const mrpValueRegex8 = /RS\.([\d.]+)/;
    const mrpValueRegex9 = /M\.R\.P\.PER STRIP OF TABS\.RS\.([\d.]+)/;
    const mrpValueRegex10 = /M\.R\.P\.PER STRIP OF TABS\. RS\.([\d.]+)/;
    const mgfDateRegex11 = /Mfg\.Date:(.+)/;
    const mrpValueRegex12 = /M\.R\.P\.RS.:([\d.]+)/;
    const mgfLicNoRegex13 = /Mfg\.Lic\.No\.:(.+)/;
    const mgfLicNoRegex14 = /MFD\.([A-Z]{3}:\d{2})/;
    const mgfLicNoRegex15 = /M\.R\. > ([\d,]+)/;

    //batch No. Start
    if (!this.BatchNo) {
      if (!this.BatchNo) {
        this.BatchNo = this.extractInformation(DataOcrUploadedImage, batchNumberRegex1);
      }
      if (!this.BatchNo) {
        this.BatchNo = this.extractInformation(DataOcrUploadedImage, batchNumberRegex2);
      }
      if (!this.BatchNo) {
        this.BatchNo = this.extractInformation(DataOcrUploadedImage, batchNumberRegex3);
      }
      if (!this.BatchNo) {
        this.BatchNo = this.extractInformation(DataOcrUploadedImage, batchNumberRegex4);
      }
      if (!this.BatchNo) {
        this.BatchNo = this.extractInformation(DataOcrUploadedImage, batchNumberRegex5);
      }
      if (!this.BatchNo) {
        this.BatchNo = this.extractInformation(DataOcrUploadedImage, batchNumberRegex6);
      }
      if (!this.BatchNo) {
        this.BatchNo = this.extractInformation(DataOcrUploadedImage, batchNumberRegex7);
      }
      if (!this.BatchNo) {
        this.BatchNo = this.extractInformation(DataOcrUploadedImage, batchNumberRegex8);
      }
      if (!this.BatchNo) {
        this.BatchNo = this.extractInformation(DataOcrUploadedImage, batchNumberRegex9);
      }
      if (!this.BatchNo) {
        this.BatchNo = this.extractInformation(DataOcrUploadedImage, batchNumberRegex10);
      }
      if (!this.BatchNo) {
        this.BatchNo = this.extractInformation(DataOcrUploadedImage, batchNumberRegex11);
      }
      if (!this.BatchNo) {
        this.BatchNo = this.extractInformation(DataOcrUploadedImage, batchNumberRegex12);
      }
      if (!this.BatchNo) {
        this.BatchNo = this.extractInformation(DataOcrUploadedImage, rebatchNumberRegex13);
      }
      if (!this.BatchNo) {
        this.BatchNo = this.extractInformation(DataOcrUploadedImage, rebatchNumberRegex14);
      }

    }

    //Manufacturing Date Start
    if (!this.ManufacturingDate) {
      if (!this.ManufacturingDate) {
        this.ManufacturingDate = this.extractInformation(DataOcrUploadedImage, manufacturingDateRegex1);
      }
      if (!this.ManufacturingDate) {
        this.ManufacturingDate = this.extractInformation(DataOcrUploadedImage, manufacturingDateRegex2);
      }
      if (!this.ManufacturingDate) {
        this.ManufacturingDate = this.extractInformation(DataOcrUploadedImage, manufacturingDateRegex3);
      }
      if (!this.ManufacturingDate) {
        this.ManufacturingDate = this.extractInformation(DataOcrUploadedImage, manufacturingDateRegex4);
      }
      if (!this.ManufacturingDate) {
        this.ManufacturingDate = this.extractInformation(DataOcrUploadedImage, manufacturingDateRegex5);
      }
      if (!this.ManufacturingDate) {
        this.ManufacturingDate = this.extractInformation(DataOcrUploadedImage, manufacturingDateRegex6);
      }
      if (!this.ManufacturingDate) {
        this.ManufacturingDate = this.extractInformation(DataOcrUploadedImage, manufacturingDateRegex7);
      }
      if (!this.ManufacturingDate) {
        this.ManufacturingDate = this.extractInformation(DataOcrUploadedImage, manufacturingDateRegex8);
      }
      if (!this.ManufacturingDate) {
        this.ManufacturingDate = this.extractInformation(DataOcrUploadedImage, manufacturingDateRegex9);
      }
      if (!this.ManufacturingDate) {
        this.ManufacturingDate = this.extractInformation(DataOcrUploadedImage, manufacturingDateRegex10);
      }
      if (!this.ManufacturingDate) {
        this.ManufacturingDate = this.extractInformation(DataOcrUploadedImage, manufacturingDateRegex11);
      }
      if (!this.ManufacturingDate) {
        this.ManufacturingDate = this.extractInformation(DataOcrUploadedImage, manufacturingDateRegex12);
      }
      if (!this.ManufacturingDate) {
        this.ManufacturingDate = this.extractInformation(DataOcrUploadedImage, manufacturingDateRegex13);
      }
      if (!this.ManufacturingDate) {
        this.ManufacturingDate = this.extractInformation(DataOcrUploadedImage, manufacturingDateRegex14);
      }
      if (!this.ManufacturingDate) {
        this.ManufacturingDate = this.extractInformation(DataOcrUploadedImage, manufacturingDateRegex15);
      }
      if (!this.ManufacturingDate) {
        this.ManufacturingDate = this.extractInformation(DataOcrUploadedImage, manufacturingDateRegex16);
      }
      if (!this.ManufacturingDate) {
        this.ManufacturingDate = this.extractInformation(DataOcrUploadedImage, manufacturingDateRegex17);
      }
      if (!this.ManufacturingDate) {
        this.ManufacturingDate = this.extractInformation(DataOcrUploadedImage, manufacturingDateRegex18);
      }
      if (!this.ManufacturingDate) {
        this.ManufacturingDate = this.extractInformation(DataOcrUploadedImage, manufacturingDateRegex19);
      }
      if (!this.ManufacturingDate) {
        this.ManufacturingDate = this.extractInformation(DataOcrUploadedImage, manufacturingDateRegex20);
      }
      if (!this.ManufacturingDate) {
        this.ManufacturingDate = this.extractInformation(DataOcrUploadedImage, manufacturingDateRegex21);
      }
    }
    //Expiry Date Start
    if (!this.ExpiryDate) {
      if (!this.ExpiryDate) {
        this.ExpiryDate = this.extractInformation(DataOcrUploadedImage, expiryDateRegex1);
      }
      if (!this.ExpiryDate) {
        this.ExpiryDate = this.extractInformation(DataOcrUploadedImage, expiryDateRegex2);
      }
      if (!this.ExpiryDate) {
        this.ExpiryDate = this.extractInformation(DataOcrUploadedImage, expiryDateRegex3);
      }
      if (!this.ExpiryDate) {
        this.ExpiryDate = this.extractInformation(DataOcrUploadedImage, expiryDateRegex4);
      }
      if (!this.ExpiryDate) {
        this.ExpiryDate = this.extractInformation(DataOcrUploadedImage, expiryDateRegex5);
      }
      if (!this.ExpiryDate) {
        this.ExpiryDate = this.extractInformation(DataOcrUploadedImage, expiryDateRegex6);
      }
      if (!this.ExpiryDate) {
        this.ExpiryDate = this.extractInformation(DataOcrUploadedImage, expiryDateRegex7);
      }
      if (!this.ExpiryDate) {
        this.ExpiryDate = this.extractInformation(DataOcrUploadedImage, expiryDateRegex8);
      }
      if (!this.ExpiryDate) {
        this.ExpiryDate = this.extractInformation(DataOcrUploadedImage, expiryDateRegex9);
      }
      if (!this.ExpiryDate) {
        this.ExpiryDate = this.extractInformation(DataOcrUploadedImage, expiryDateRegex10);
      }
      if (!this.ExpiryDate) {
        this.ExpiryDate = this.extractInformation(DataOcrUploadedImage, expiryDateRegex11);
      }
      if (!this.ExpiryDate) {
        this.ExpiryDate = this.extractInformation(DataOcrUploadedImage, expiryDateRegex12);
      }
      if (!this.ExpiryDate) {
        this.ExpiryDate = this.extractInformation(DataOcrUploadedImage, expiryDateRegex13);
      }
      if (!this.ExpiryDate) {
        this.ExpiryDate = this.extractInformation(DataOcrUploadedImage, expiryDateRegex14);
      }
      if (!this.ExpiryDate) {
        this.ExpiryDate = this.extractInformation(DataOcrUploadedImage, expiryDateRegex15);
      }
      if (!this.ExpiryDate) {
        this.ExpiryDate = this.extractInformation(DataOcrUploadedImage, expiryDateRegex16);
      }
      if (!this.ExpiryDate) {
        this.ExpiryDate = this.extractInformation(DataOcrUploadedImage, expiryDateRegex17);
      }
      if (!this.ExpiryDate) {
        this.ExpiryDate = this.extractInformation(DataOcrUploadedImage, expiryDateRegex18);
      }
      if (!this.ExpiryDate) {
        this.ExpiryDate = this.extractInformation(DataOcrUploadedImage, expiryDateRegex19);
      }
      if (!this.ExpiryDate) {
        this.ExpiryDate = this.extractInformation(DataOcrUploadedImage, expiryDateRegex20);
      }
      if (!this.ExpiryDate) {
        this.ExpiryDate = this.extractInformation(DataOcrUploadedImage, expiryDateRegex21);
      }
    }
    //MRP Start
    if (!this.MrpRs) {
      if (!this.MrpRs) {
        this.MrpRs = this.extractInformation(DataOcrUploadedImage, mrpValueRegex1);
      }
      if (!this.MrpRs) {
        this.MrpRs = this.extractInformation(DataOcrUploadedImage, mrpValueRegex2);
      }
      if (!this.MrpRs) {
        this.MrpRs = this.extractInformation(DataOcrUploadedImage, mrpValueRegex3);
      }
      if (!this.MrpRs) {
        this.MrpRs = this.extractInformation(DataOcrUploadedImage, mrpValueRegex4);
      }
      if (!this.MrpRs) {
        this.MrpRs = this.extractInformation(DataOcrUploadedImage, mrpValueRegex5);
      }
      if (!this.MrpRs) {
        this.MrpRs = this.extractInformation(DataOcrUploadedImage, mrpValueRegex6);
      }
      if (!this.MrpRs) {
        this.MrpRs = this.extractInformation(DataOcrUploadedImage, mrpValueRegex7);
      }
      if (!this.MrpRs) {
        this.MrpRs = this.extractInformation(DataOcrUploadedImage, mrpValueRegex8);
      }
      if (!this.MrpRs) {
        this.MrpRs = this.extractInformation(DataOcrUploadedImage, mrpValueRegex9);
      }
      if (!this.MrpRs) {
        this.MrpRs = this.extractInformation(DataOcrUploadedImage, mrpValueRegex10);
      }
      if (!this.MrpRs) {
        this.MrpRs = this.extractInformation(DataOcrUploadedImage, mgfDateRegex11);
      }
      if (!this.MrpRs) {
        this.MrpRs = this.extractInformation(DataOcrUploadedImage, mrpValueRegex12);
      }
      if (!this.MrpRs) {
        this.MrpRs = this.extractInformation(DataOcrUploadedImage, mgfLicNoRegex13);
      }
      if (!this.MrpRs) {
        this.MrpRs = this.extractInformation(DataOcrUploadedImage, mgfLicNoRegex14);
      }
      if (!this.MrpRs) {
        this.MrpRs = this.extractInformation(DataOcrUploadedImage, mgfLicNoRegex15);
      }
    }

    //printed here after getting values.
    console.log('Batch Number:', this.BatchNo);
    console.log('Manufacturing Date:', this.ManufacturingDate);
    console.log('Expiry Date:', this.ExpiryDate);
    console.log('M.R.P. Value:', this.MrpRs);
    this.ValidDateFormat(this.ManufacturingDate, this.ExpiryDate);
  }

  ValidDateFormat(ManufacturingDate: any, ExpiryDate: any) {
    debugger;
    // ManufacturingDate = "JAN:22008";
    // ExpiryDate = "JAN:";
    // this.ManufacturingDateSubstring(ManufacturingDate);
    // this.ExpiryDateDevideSubstring(ExpiryDate);
    this.ManufacturingDateYear = "";
    this.ManufacturingDateMonth = "";
    this.ExpiryDateMonth = "";
    this.ExpiryDateYear = "";
    if ((ManufacturingDate.length <= 6 && ExpiryDate.length <= 6)) {
      this.ManufacturingDateSubstring(ManufacturingDate);
      this.ExpiryDateDevideSubstring(ExpiryDate);
    }
    if (ManufacturingDate.length >= 6 && ExpiryDate.length >= 6) {
      this.ManufacturingDateSubstring(ManufacturingDate);
      this.ExpiryDateDevideSubstring(ExpiryDate);
    }
    if ((ManufacturingDate.length > 6)) {
      this.ManufacturingDateSubstring(ManufacturingDate);
    }
    if (ManufacturingDate.length <= 6) {
      this.ManufacturingDateSubstring(ManufacturingDate);
    }
    if (ExpiryDate.length > 6) {
      this.ExpiryDateDevideSubstring(ExpiryDate);
    }
    if (ExpiryDate.length <= 6) {
      this.ExpiryDateDevideSubstring(ExpiryDate);
    }
    if (this.ManufacturingDateYear.length === 2 || this.ExpiryDateYear.length === 2) {
      this.ManufacturingDateYear = "20" + this.ManufacturingDateYear;
      this.ExpiryDateYear = "20" + this.ExpiryDateYear;
      this.ConvertorConcateData();
    }
    this.ConvertorConcateData();
    console.log("Formatted Date ManufacturingDate -> ", this.ManufacturingDate);
    console.log("Formatted Date ExpiryDate -> ", this.ExpiryDate);
  }

  ExpiryDateDevideSubstring(ExpiryDate: any) {
    this.ExpiryDateMonth = ExpiryDate.substring(3, 0);
    this.ExpiryDateYear = ExpiryDate.substring(4, 10);
  }

  ManufacturingDateSubstring(ManufacturingDate: any) {
    this.ManufacturingDateMonth = ManufacturingDate.substring(3, 0);
    this.ManufacturingDateYear = ManufacturingDate.substring(4, 10);
  }

  ConvertorConcateData() {
    this.ManufaturingDateFormat = String("01" + "-" + this.ManufacturingDateMonth + "-" + this.ManufacturingDateYear);
    this.ManufacturingDate = this.DateFormatForDDMMYYYY(this.ManufaturingDateFormat);
    this.ExpiryDateFormat = String("01" + "-" + this.ExpiryDateMonth + "-" + this.ExpiryDateYear);
    this.ExpiryDate = this.DateFormatForDDMMYYYY(this.ExpiryDateFormat);
  }

  //return date format
  DateFormatForDDMMYYYY(CommonDateFormat: any) {
    return formatDate(CommonDateFormat, 'dd-MM-yyyy', 'en-US')
  }

  // Match key and Return value
  extractInformation(str: any, regex: any) {
    const match = str.match(regex);
    return match ? match[1] : null
  }

  //destroy
  ngOnDestroy(): void {
    this.listSubscribers.forEach(a => a.unsubscribe());
  }

  onImageSelected(event: Event): void {
    debugger
    const file = (event.target as HTMLInputElement).files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        this.imageUrl = reader.result as string;
        this.recognizeText();
      };
      reader.readAsDataURL(file);
    }
  }

  async recognizeText(): Promise<void> {
    debugger
    this.IamgeForOCRPath = "gs://cloud-samples-data/vision/cfaocrbucker/image1.png";
    if (!this.IamgeForOCRPath) {
      return;
    }
    try {
      const apiKey = 'AIzaSyATYLQXmN9Y1NX-e3Nc8Tklun4ah0wQmM0';
      const headers = new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`
      });
      const requestData = {
        requests: [
          {
            image: {
              content: this.IamgeForOCRPath
            },
            features: [
              {
                type: 'TEXT_DETECTION'
              }
            ]
          }
        ]
      };
      const apiUrl = 'https://vision.googleapis.com/v1/images:annotate';
      const response: any = await this.httptest.post(apiUrl, requestData, { headers }).toPromise();

      if (response?.responses?.[0]?.textAnnotations?.[0]?.description) {
        this.recognizedText = response.responses[0].textAnnotations[0].description;
        console.log('Recognized Text:', this.recognizedText);
      } else {
        this.recognizedText = 'No text found.';
      }
    } catch (error) {
      console.error('Error recognizing text:', error);
    }
  }

  imageDataBucket: any;
  getImage() {
    debugger
    const bucketName = 'cfaoctrbucker';
    const imageName = 'image1.png';

    this._service.getImage(bucketName, imageName)
      .then((imageBlob: any) => {
        this.imageDataBucket = this.createImageFromBlob(imageBlob);
        console.log('image', this.imageDataBucket)
      })
      .catch((error: any) => {
        console.error(error.message);
      });
  }

  createImageFromBlob(imageBlob: Blob): any {
    debugger
    console.log('imageBlob', imageBlob)
    const reader = new FileReader();
    return new Promise((resolve, reject) => {
      reader.onloadend = () => {
        resolve(reader.result);
      };
      reader.onerror = reject;
      reader.readAsDataURL(imageBlob);
    });
  }
}
