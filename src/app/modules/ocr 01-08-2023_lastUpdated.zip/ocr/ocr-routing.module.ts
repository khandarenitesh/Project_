import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { OcrIntegrationComponent } from './ocr-integration/ocr-integration.component';

const routes: Routes = [
  {
    path: 'ocr-integration',
    component: OcrIntegrationComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class OCRRoutingModule { }
