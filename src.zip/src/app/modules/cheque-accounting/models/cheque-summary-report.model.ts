export class ChqSummaryForMonthlyModel {
    CompId: number = 0;
    BranchId: number = 0;
    // FromDate: string | null;
    // ToDate: string | null;
    FromDate : Date = new Date();
    ToDate : Date = new Date();
}