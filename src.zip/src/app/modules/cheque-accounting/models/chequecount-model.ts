export class Chequecounts {
    Total: number = 0;
    Blank: number = 0;
    Utilised: number = 0;
    Prepare: number = 0;
    Deposited: number = 0;
    Discarded: number = 0;
    Returned: number = 0;
    Settled: number = 0;
}