import { ChqAcPaginatorDirective } from './chq-ac-paginator.directive';

describe('ChqAcPaginatorDirective', () => {
  it('should create an instance', () => {
    const directive = new ChqAcPaginatorDirective();
    expect(directive).toBeTruthy();
  });
});
