import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-account-module',
  templateUrl: './account-module.component.html',
  styleUrls: ['./account-module.component.scss']
})
export class AccountModuleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
